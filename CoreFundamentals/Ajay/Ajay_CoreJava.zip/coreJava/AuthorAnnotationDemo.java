package ace.sape.coreJava;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target ({ElementType.FIELD,ElementType.METHOD})
 @interface CustonAnnotation{
	String authorName();
	String emailId();
	String employeeType() default  "PERMANENT";
}

class Employee1{
	@CustonAnnotation(authorName="Ajay",emailId="ajay@sapient.com")
	String name;
	String email;
	String empType;	
}

public class AuthorAnnotationDemo {
	
	public static void main(String[] args) {
		Employee1 emp=new Employee1();
		Class c=emp.getClass();
		Annotation an=c.getAnnotation(CustonAnnotation.class);
		CustonAnnotation cus=(CustonAnnotation)an;
		System.out.println(cus.authorName());
		System.out.println(cus.emailId());
		System.out.println(cus.employeeType());
		
		

	}

}

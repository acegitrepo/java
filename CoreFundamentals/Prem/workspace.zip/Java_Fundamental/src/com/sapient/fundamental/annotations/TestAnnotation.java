package com.sapient.fundamental.annotations;

import java.lang.reflect.Method;

@ClassPreamble(author = "John Doe", date = "3/17/2002", currentRevision = 6, lastModified = "4/12/2004", lastModifiedBy = "Jane Doe",
		// Note array notation
		reviewers = { "Alice", "Bob", "Cindy" })

public class TestAnnotation {

	@Todo(comment = "Need to implement")
	public void methodToBeImplemented() {

	}

	@Schedule(dayOfMonth = "last")
	@Schedule(dayOfWeek = "Fri", hour = 23)
	public void doPeriodicCleanup() {

	}

	public static void main(String[] args) throws Exception {
		Method[] methods = TestAnnotation.class.getMethods();
		for (Method me : methods) {
			Todo annotation = me.getAnnotation(Todo.class);
			Schedules schedules = me.getAnnotation(Schedules.class);

			if (annotation != null)
				System.out.println(me.getName() + " : " + annotation.comment());

			if (schedules != null)
				System.out.println(me.getName() + " : " + schedules.value());
		}

		ClassPreamble preamble = TestAnnotation.class.getAnnotation(ClassPreamble.class);
		if (preamble != null) {
			System.out.println(preamble.author() + " : " + preamble.reviewers());
		}
		
		

	}
	
	//http://www.pointsoftware.ch/de/under-the-hood-runtime-data-areas-javas-memory-model/
}

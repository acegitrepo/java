package com.sapient.java.fundamental.domain;

import java.io.Serializable;

public class Address  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String streetName;
	
	private String  houseNo;
	
	private String city;
	
	
	private Long pinCode;


	public Address(String streetName, String houseNo, String city, Long pinCode) {
		this.streetName = streetName;
		this.houseNo = houseNo;
		this.city = city;
		this.pinCode = pinCode;
	}


	public Address(Address address) {
		this.streetName = address.streetName;
		this.houseNo = address.houseNo;
		this.city = address.city;
		this.pinCode = address.pinCode;

		
	}


	@Override
	public String toString() {
		return "Address [streetName=" + streetName + ", houseNo=" + houseNo + ", city=" + city + ", pinCode=" + pinCode
				+ "]";
	}
	
	
	
	
	
	

}

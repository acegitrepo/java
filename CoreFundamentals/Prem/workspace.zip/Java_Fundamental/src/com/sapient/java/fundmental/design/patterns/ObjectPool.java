package com.sapient.java.fundmental.design.patterns;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.sapient.java.fundamental.domain.Department;
import com.sapient.java.fundamental.domain.Employee;

public class ObjectPool<T> {

	private final Map<String, BlockingQueue<T>> pool = new ConcurrentHashMap<>();

	public static final ObjectPool<Object> INSTANCE = new ObjectPool<>();

	private ObjectPool() {

	}

	public void createPool(T obj, int size) {

		BlockingQueue<T> queue = new ArrayBlockingQueue<>(size);

		for (int i = 0; i < size; i++) {
			queue.add(obj);

		}

		pool.put(obj.getClass().getName(), queue);

	}

	/*
	 * 
	 * Class Name is fully Qualified ClassName
	 * 
	 */
	public T obtainFromPool(String className) {
		T obj = null;
		try {
			
			
			System.out.println(String.format("Pool Size before  pooling object  %s : %d " , className, pool.get(className).size()));
			Thread.sleep(1000);

			
			obj = pool.get(className).poll(10000, TimeUnit.MILLISECONDS);

			
			System.out.println(String.format("Pool Size after  pooling object  %s : %d " , className, pool.get(className).size()));


		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return obj;
	}

	public void releaseToPool(T object) {
		try {
			System.out.println(String.format("Pool Size before  returning object  %s : %d " , object.getClass().getName(), pool.get(object.getClass().getName()).size()));

			pool.get(object.getClass().getName()).offer(object, 1000l, TimeUnit.MILLISECONDS);

			System.out.println(String.format("Pool Size after  returning object  %s : %d " , object.getClass().getName(), pool.get(object.getClass().getName()).size()));

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws Exception {

		ObjectPool.INSTANCE.createPool(new Employee(), 10);

		ObjectPool.INSTANCE.createPool(new Department("HR", 1l), 10);

		ExecutorService service = Executors.newFixedThreadPool(10);

		for (int i = 0; i < 10; i++) {
			service.execute(() -> {
				try {
					Employee emp = (Employee) ObjectPool.INSTANCE.obtainFromPool(Employee.class.getName());

					emp.setName("Amit");

					ObjectPool.INSTANCE.releaseToPool(emp);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			);
			
			service.execute(() -> {
				try {
					Department dept = (Department) ObjectPool.INSTANCE.obtainFromPool(Department.class.getName());
					Thread.sleep(10000);

					ObjectPool.INSTANCE.releaseToPool(dept);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			);

		}
	}

}

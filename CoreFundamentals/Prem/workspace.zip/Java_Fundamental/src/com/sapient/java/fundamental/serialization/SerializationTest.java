package com.sapient.java.fundamental.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.sapient.java.fundamental.domain.Address;
import com.sapient.java.fundamental.domain.Department;
import com.sapient.java.fundamental.domain.Employee;
import com.sapient.java.fundamental.domain.Person;

public class SerializationTest {
	
	public static void main(String[] args) throws Exception {
		Employee emp = new Employee();
		emp.setName("Amit Porwal");
		emp.setId(104022);
		emp.setAlternateName("AmitP");

		Address add = new Address("SouthCity1", "Gurgaon", "K207", 122001l);
		emp.setAddress(add);

		Department dept = new Department("Global Markets", 311l);
		emp.setDepartment(dept);

		FileOutputStream fileOut = new FileOutputStream("C://emp.ser");
		ObjectOutputStream objOut = new ObjectOutputStream(fileOut);

		System.out.println("Serialising Employee" + emp);
		objOut.writeObject(emp);

		System.out.println("DeSerialising Employee");

		FileInputStream fileInput = new FileInputStream("C://emp.ser");
		ObjectInputStream objInput = new ObjectInputStream(fileInput);

		Employee serializedEmp = (Employee) objInput.readObject();
		
		

		System.out.println(serializedEmp);

	}


}

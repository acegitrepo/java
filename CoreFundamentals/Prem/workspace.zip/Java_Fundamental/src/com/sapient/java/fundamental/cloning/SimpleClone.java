package com.sapient.java.fundamental.cloning;

import com.sapient.java.fundamental.domain.Address;
import com.sapient.java.fundamental.domain.Department;
import com.sapient.java.fundamental.domain.Employee;

public class SimpleClone {
	
	public static void main(String[] args) throws Exception {
		
		
		
		Employee emp = new Employee();
		emp.setName("Amit Porwal");
		emp.setId(104022);
		emp.setAlternateName("champ");

		Address add = new Address("SouthCity1", "Gurgaon", "K207", 122001l);
		emp.setAddress(add);

		Department dept = new Department("Global Markets", 311l);
		emp.setDepartment(dept);

//		Employee clone =(Employee) emp.clone();
		
		Employee clone = (Employee)emp.clone();
		
		System.out.println(clone==emp);
		
		System.out.println(clone.getAddress()==emp.getAddress());
		
		System.out.println(clone.getDepartment()==emp.getDepartment());

		
		
		
	}
}

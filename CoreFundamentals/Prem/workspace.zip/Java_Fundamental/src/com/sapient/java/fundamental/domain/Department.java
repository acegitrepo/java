package com.sapient.java.fundamental.domain;

import java.io.Serializable;

public class Department implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private String deptName;
	
	private Long deptId;

	public Department(String deptName, Long deptId) {
		this.deptName = deptName;
		this.deptId = deptId;
	}
	
	
	public Department(Department department) {
		this.deptName = department.deptName;
		this.deptId = department.deptId;
	}


	@Override
	public String toString() {
		return "Department [deptName=" + deptName + ", deptId=" + deptId + "]";
	}

	 

}

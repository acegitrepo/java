package com.sapient.java.multithreading.executors;

import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ProducerConsumer {

	private static final BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);

	public static void main(String[] args) throws Exception {
		ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(10);
		for (int i = 0; i < 10; i++) {
				newFixedThreadPool.submit(new Producer(queue));
				newFixedThreadPool.submit(new Consumer(queue));

		}
		
	}

	private static class Producer implements Callable<Boolean> {

		private BlockingQueue<Integer> queue;

		public Producer(BlockingQueue<Integer> queue) {
			this.queue = queue;
		}

		@Override
		public Boolean call() throws Exception {
			boolean success = true;
			try {
				System.out.println("Sleeping for 1 second before adding to queue");
				Thread.sleep(2000);
				System.out.println("Adding random integer to queue");
				success = queue.offer(new Random().nextInt(10000), 100000, TimeUnit.MILLISECONDS);
				if (!success) { 
					System.out.println("Not able to add element after waiting for more than 10 seconds");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return success;

		}

	}

	private static class Consumer implements Callable<Integer> {

		private BlockingQueue<Integer> queue;

		public Consumer(BlockingQueue<Integer> queue) {
			this.queue = queue;
		}

		@Override
		public Integer call() throws Exception {
			Integer result = 0;
			try {
				System.out.println("pooling random integer to queue");	
				result = queue.poll(1000, TimeUnit.MILLISECONDS);
				if(result == null) {
					throw new RuntimeException("Time out while pooling from queue");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return result;

		}

	}

}

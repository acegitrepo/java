package com.sapient.java.fundamental.domain;

import java.io.Serializable;

public class Person 
//implements Serializable
{

	
	public Person() {
		System.out.println("Person Constructor called");
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String name;
	protected Address address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", address=" + address + "]";
	}
	
	

}

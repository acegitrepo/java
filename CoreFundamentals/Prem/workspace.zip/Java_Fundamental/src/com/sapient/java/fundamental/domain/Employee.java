package com.sapient.java.fundamental.domain;

import java.io.Serializable;

public class Employee extends Person implements Serializable, Cloneable {

	/**
	 * 
	 */
	// private static final long serialVersionUID = 746583466575518468L;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private Department department;

	private transient String alternateName;
	
//	private static String staticField;

	public String getAlternateName() {
		return alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	
//	public  Object clone() throws CloneNotSupportedException {
//		return super.clone();
//	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public  Object clone() throws CloneNotSupportedException {
		    Employee empClone = new Employee();
		    
		    Address add = new Address(this.getAddress());
		    Department dept = new Department(this.getDepartment());
		    
		    empClone.setAddress(add);
		    empClone.setDepartment(dept);
		    empClone.setId(this.getId());
		    empClone.setName(this.getName());
		    return empClone;
		    
		    
	}

}

package ace.sape.coreJava;
class Employee{
	int id;
	String name;
	String address;
	String projectName;
	public Employee(int id,String name,String address,String projectName){
		this.id=id;
		this.name=name;
		this.address=address;
		this.projectName=projectName;
	}
	public void showDetails(){
		System.out.println("Id is "+id);
		System.out.println("Name is "+name);
		System.out.println("Address is "+address);
		System.out.println("Project name is "+projectName);
		
	}
}

public class EmployeeDemo {

	public static void main(String[] args) {
		Employee employee=new Employee(10, "Neha", "b-23,Noida", "GSAM");
		employee.showDetails();
		

	}

}

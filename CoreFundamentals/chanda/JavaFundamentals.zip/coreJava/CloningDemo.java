package ace.sape.coreJava;
class Fruits implements Cloneable{
	String name;
	String colour;
	public Fruits(String name,String colour){
		this.name=name;
		this.colour=colour;
	}
	@Override
	public String toString() {
		return "Fruits [name=" + name + ", colour=" + colour + "]";
	}
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
		
	}
}

public class CloningDemo {

	public static void main(String[] args) throws CloneNotSupportedException {
		Fruits fruits=new Fruits("Apple", "Red");
		Fruits fruits2=(Fruits)fruits.clone();
		System.out.println(fruits);
		System.out.println(fruits2);
		fruits.name="Grapes";
		System.out.println(fruits);
		System.out.println(fruits2);

	}

}

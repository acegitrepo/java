package ace.sape.coreJava;

class A{
	int i;
	int j;
	@Override
	public String toString() {
		return "A [i=" + i + ", j=" + j + "]";
	}
	
}
public class ShallowDemo {

	public static void main(String[] args) {
		A obj=new A();
		obj.i=5;
		obj.j=6;
		A obj1=obj;       //shallow copy
		System.out.println(obj);
		System.out.println(obj1);
		obj1.i=10;
		System.out.println(obj);
		System.out.println(obj1);
		
		//Deep Copy
		A obj2=new A();
		obj2.i=5;
		obj2.j=6;
		System.out.println(obj);
		System.out.println(obj2);
		
		

	}

}

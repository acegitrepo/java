package com.ankit.cloning;

public class TestClone {
	public static void main(String[] args) throws CloneNotSupportedException {
		Address a = new Address();
		a.setHouseNO(201);
		Employee e = new Employee();
		e.setName("Ankit");
		e.setAdr(a);

		Employee e1 = (Employee) e.clone();
		System.out.println(e1==e);
		System.out.println(e1.getAdr()==e.getAdr());
	}
}

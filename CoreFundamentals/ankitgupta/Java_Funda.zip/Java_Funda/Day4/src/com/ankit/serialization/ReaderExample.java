package com.ankit.serialization;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReaderExample {
	public static void main(String[] args) {

		try {
			int count = 0;
			int words = 0;
			int chars = 0;
			/*
			 * // Reader reader =new BufferedReader(new FileReader(new
			 * File("C:\\Users\\agu226\\Desktop\\sample.txt"))); Reader reader
			 * =new BufferedReader(new FileReader(new
			 * File("C:\\Users\\agu226\\Desktop\\sample.txt")));
			 * while(reader.read()!=-1){ count++; }
			 */
			BufferedReader reader1 = new BufferedReader(
					new FileReader(new File("C:\\Users\\agu226\\Desktop\\sample.txt")));
			String temp = null;
			while ((temp = reader1.readLine()) != null) {
				System.out.println(temp);
				for (String s : temp.split("\\s+"))
					count += s.length();

			}
			System.out.println(count);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package com.ankit.cloning;

public class Employee extends Address implements Cloneable {
	private String name;
	private Address adr;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAdr() {
		return adr;
	}

	public void setAdr(Address adr) {
		this.adr = adr;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		Employee copyObj = new Employee();
		copyObj.setName(this.name);
		copyObj.setAdr(new Address(this.adr));
		return copyObj;
	}
}

class Address {
	private int houseNO;

	public Address() {

	}

	public Address(Address s) {
		houseNO = s.houseNO;
	}

	public int getHouseNO() {
		return houseNO;
	}

	public void setHouseNO(int houseNO) {
		this.houseNO = houseNO;
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

}
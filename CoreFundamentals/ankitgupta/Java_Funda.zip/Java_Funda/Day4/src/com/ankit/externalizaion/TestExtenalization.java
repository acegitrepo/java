package com.ankit.externalizaion;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.ankit.externalizaion.Employee;

public class TestExtenalization {
	public static void main(String[] args) {
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream("C://emp.ser");
			ObjectOutputStream output = new ObjectOutputStream(fileOut);

			Employee person = new Employee();
			person.setFirstName("Ankit");
			person.setLastName(10L);
			output.writeObject(person);
			FileInputStream fileInput = new FileInputStream("C://emp.ser");
			ObjectInputStream input = new ObjectInputStream(fileInput);

			Employee per = (Employee) input.readObject();
			System.out.println(per.getFirstName());
			System.out.println(per.getLastName());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

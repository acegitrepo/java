package com.ankit.serialization;

import java.io.IOException;
import java.io.Serializable;

public class Person implements Serializable {

	/**
	 * SerialVersion UID
	 */
	private static final long serialVersionUID = -5025055915400356212L;
	
	private String firstName;
	private Long lastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	
	public Long getLastName() {
		return lastName;
	}

	public void setLastName(Long lastName) {
		this.lastName = lastName;
	}

	private void writeObject(java.io.ObjectOutputStream stream)
            throws IOException {
        stream.writeObject(firstName+" gupta");
        stream.writeLong(lastName);
    }
	private void readObject(java.io.ObjectInputStream stream)
            throws IOException, ClassNotFoundException {		
       
        firstName = (String) stream.readObject();
        lastName =stream.readLong();
    }


}

package sample;

class A2{
	public static void m1(){
		System.out.println("1");
	}
	public void m2(){
		System.out.println("2");
	}
	public A2(){
		m1();
		this.m2();
	}
}
class B2 extends A2{
	public static void m1(){
		System.out.println("3");
	}
	public  void m2(){
		System.out.println("4");
	}
}
public class Test4 {
public static void main(String[] args) {
	A2 a = new B2();
	String s= new String("Ankit");
	String s1="Ankit";
	System.out.println(s.equals(s1));
	System.out.println(s==s1);
	System.out.println(s.intern()==s1);
	
}
}

package sample;

import java.io.IOException;

class AA1 {
	public void print() throws Exception{
		throw new Exception();
	}
}

class B1 extends AA1 {
	public void print() throws IOException{		
		throw new IOException();
	}
}

public class Test3 {
	public static void main(String[] args) {
		B1 b =new B1();
		try{
			b.print();
		}catch(IOException io){
			System.out.println("ank");
		}catch (Exception e) {
			System.out.println("ak");
		}
	}
}
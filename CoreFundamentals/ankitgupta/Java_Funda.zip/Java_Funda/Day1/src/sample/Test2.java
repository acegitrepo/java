package sample;

class AA {
	{
		System.out.println("3");
	}

	AA() {
		System.out.println("0");
	}
}

class B extends AA {
	{
		System.out.println("1");
	}

	B() {
		System.out.println("2");
	}
	B(int a) {
		this();
		System.out.println("5");
	}
}

public class Test2 {
	public static void main(String[] args) {
		//new B();
		new B(3);
	}
}

package sample;

public class Test1 {

	public static void main(String[] args) {
		System.out.println("in main");
		A a = new A();
		a.ank();
	}
}

class A {
	/*
	 * static { try { System.out.println(1 / 0); } catch (Exception a) {
	 * System.out.println("Exception handled"); } }
	 */

	static void ank() {
		System.out.println("Ankit");
	}
}
package com.ankit.Lift;

public enum LiftTypeEnum {
	serviceLift, passengerLift;
}

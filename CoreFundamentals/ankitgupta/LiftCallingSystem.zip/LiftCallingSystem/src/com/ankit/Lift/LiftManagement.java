package com.ankit.Lift;

import java.util.Scanner;

public class LiftManagement {
	private Lift _serviceLift;
	private Lift _passengerLift;

	public LiftManagement() {
		long starts = System.currentTimeMillis();
		_serviceLift = new Lift(0, starts, LiftTypeEnum.serviceLift);
		_passengerLift = new Lift(0, starts, LiftTypeEnum.passengerLift);
	}

	public static void main(String[] args) {
		LiftManagement liftManagement = new LiftManagement();
		Scanner in = null;
		Thread thread = new Thread(new Runnable() {
			long currentTimeinMS = 0;

			@Override
			public void run() {
				while (true) {
					currentTimeinMS = System.currentTimeMillis();
					if (((currentTimeinMS - liftManagement.get_serviceLift()
							.getLastUsed()) / 1000) >= 30) {
						if (liftManagement.get_passengerLift()
								.getCurrentFloor() != 0) {
							liftManagement.get_serviceLift().setCurrentFloor(0);
						}
					}
					if (((currentTimeinMS - liftManagement.get_passengerLift()
							.getLastUsed()) / 1000) >= 30) {
						if (liftManagement.get_serviceLift().getCurrentFloor() != 0) {
							liftManagement.get_passengerLift().setCurrentFloor(
									0);
						}
					}
				}
			}
		});
		thread.setDaemon(true);
		thread.start();
		while (true) {
			in = new Scanner(System.in);
			System.out.println(" Lift Calling System");
			System.out.println("Press 1 to know the status of the lift");
			System.out
					.println("Press 2 to display the prompt to enter floor number");
			Integer input = in.nextInt();
			if (input == 1) {
				liftManagement.displayFloor();
			} else if (input == 2) {
				System.out.println("Enter the Lift number between 0-9");
				int floorNo = in.nextInt();
				liftManagement.callLift(floorNo);
				liftManagement.displayFloor();
			}
			in.close();

		}
	}

	private void callLift(int floorNo) {
		int _floorNo = floorNo;
		int serviceLiftDiff = Math.abs(get_serviceLift().getCurrentFloor()
				- _floorNo);
		int passengerLiftDiff = Math.abs(get_passengerLift().getCurrentFloor()
				- _floorNo);

		if (serviceLiftDiff > passengerLiftDiff) {
			get_passengerLift().setCurrentFloor(_floorNo);
		} else if (serviceLiftDiff < passengerLiftDiff) {
			get_serviceLift().setCurrentFloor(_floorNo);
		} else {
			if (get_serviceLift().getCurrentFloor() > floorNo) {
				get_serviceLift().setCurrentFloor(_floorNo);
				;
			} else {
				get_passengerLift().setCurrentFloor(_floorNo);
				;
			}
		}
	}

	private void displayFloor() {
		System.out.println("Service Lift at Floor :"
				+ get_serviceLift().getCurrentFloor());
		System.out.println("Passenger Lift at Floor :"
				+ get_passengerLift().getCurrentFloor());

	}

	public Lift get_passengerLift() {
		return _passengerLift;
	}

	public Lift get_serviceLift() {
		return _serviceLift;
	}
}

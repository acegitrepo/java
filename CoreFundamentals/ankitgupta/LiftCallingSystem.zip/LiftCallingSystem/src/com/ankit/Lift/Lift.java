package com.ankit.Lift;


public class Lift {
	private int currentFloor;
	private long lastUsed;
	private LiftTypeEnum lifttype;

	public Lift(int currentFloor, long lastUsed, LiftTypeEnum liftType) {
		this.currentFloor = currentFloor;
		this.lastUsed = lastUsed;
		this.lifttype = liftType;
	}

	public long getLastUsed() {
		return lastUsed;
	}

	public int getCurrentFloor() {
		return currentFloor;
	}

	public void setCurrentFloor(int currentFloor) {
		this.currentFloor = currentFloor;
		this.lastUsed=System.currentTimeMillis();
	}

	public LiftTypeEnum getLifttype() {
		return lifttype;
	}
}

package com.ankit.userInterface;

public class Lift1 {
	public static Integer _serviceLift_FloorNo = 0;
	public static Integer _passangerLift_FloorNo = 0;

	public static void displayFloor() {
		System.out.println("Service Lift at Floor :" + _serviceLift_FloorNo);
		System.out.println("Service Lift at Floor :" + _passangerLift_FloorNo);
	}

	public static void callLift(Integer floorNo) {
		Integer _floorNo = floorNo;
		if (_serviceLift_FloorNo > _floorNo
				&& _passangerLift_FloorNo > _floorNo) {
			if ((_serviceLift_FloorNo - _floorNo) >= (_passangerLift_FloorNo - _floorNo)) {
				_passangerLift_FloorNo = floorNo;
			} else {
				_serviceLift_FloorNo = floorNo;
			}
		} else if (_serviceLift_FloorNo > _floorNo
				&& _passangerLift_FloorNo < _floorNo) {
			if ((_serviceLift_FloorNo - _floorNo) >= (_floorNo - _passangerLift_FloorNo)) {
				_passangerLift_FloorNo = floorNo;
			} else {
				_serviceLift_FloorNo = floorNo;
			}
		} else if (_serviceLift_FloorNo < _floorNo
				&& _passangerLift_FloorNo > _floorNo) {
			if ((_floorNo - _serviceLift_FloorNo) >= (_passangerLift_FloorNo - _floorNo)) {
				_passangerLift_FloorNo = floorNo;
			} else {
				_serviceLift_FloorNo = floorNo;
			}
		} else if (_serviceLift_FloorNo < _floorNo
				&& _passangerLift_FloorNo < _floorNo) {
			if ((_floorNo - _serviceLift_FloorNo) >= (_floorNo - _passangerLift_FloorNo)) {
				_passangerLift_FloorNo = floorNo;
			} else {
				_serviceLift_FloorNo = floorNo;
			}
		}
	}
}

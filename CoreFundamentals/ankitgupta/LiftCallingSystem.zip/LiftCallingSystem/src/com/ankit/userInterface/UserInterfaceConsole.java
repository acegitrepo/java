package com.ankit.userInterface;

import java.util.Scanner;

public class UserInterfaceConsole {
	public static void main(String[] args) {
		Scanner in = null;
		while (true) {
			in = new Scanner(System.in);
			System.out.println(" Lift Calling System");
			System.out.println("Press 1 to know the status of the lift");
			System.out
					.println("Press 2 to display the prompt to enter floor number");
			Integer input = in.nextInt();
			if (input == 1) {
				Lift1.displayFloor();
			} else if (input == 2) {
				System.out.println("Enter the Lift number between 0-9");
				Integer floorNo = in.nextInt();
				Lift1.callLift(floorNo);
				Lift1.displayFloor();
			}
			in.close();
		}
	}
}

package com.prac.fina;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeMain {
	public static void main(String[] args) {

		
		Employee_Serial emp = new Employee_Serial();
		
		  emp.setEmployeeId(101);
		  emp.setEmployeeName("gaurav");
		  emp.setDepartment("CS");
		  emp.setName2("Ajay");
		  try{
		   FileOutputStream fileOut = new FileOutputStream("d:/Employeewe_Serial.ser");
		   ObjectOutputStream outStream = new ObjectOutputStream(fileOut);
		   outStream.writeObject(emp);
		   outStream.close();
		   fileOut.close();
		  }catch(IOException i){
		  i.printStackTrace();
		  }
		
		 }

}

package com.prac.fina;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Employee_Serial emp = null;
	
          try{
		     FileInputStream fileIn =new FileInputStream("d:/Employee_Serial.ser");
		     ObjectInputStream in = new ObjectInputStream(fileIn);
		      emp = (Employee_Serial) in.readObject();
		      emp.setEmployeeId(500);
		      in.close();
		      fileIn.close();
		  }catch(IOException i){
		    i.printStackTrace();
		    return;
		     }catch(ClassNotFoundException c){
		       System.out.println("'Employee class not found'");
		       c.printStackTrace();
		       return;
		     }
		        System.out.println("'Deserialized Employee...");
		       
		       System.out.println("'Emp id: '"+ emp.getEmployeeId());
		        System.out.println("'Name: '" + emp.getEmployeeName());
		        System.out.println("'Department: '" + emp.getDepartment());
		        System.out.println("'Emp name: '"+ emp.getName());
		        
		        System.out.println("'Emp name 1: '"+ emp.getName1());
		        System.out.println("'Emp name 2: '"+ Employee_Serial.getName2());
	}

}

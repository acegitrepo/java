package com.prac.fina;

import java.io.Serializable;

public class Employee_Serial implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -8871554064677230269L;


	int employeeId;
    String employeeName;
	String department;
	transient String name="Himani";
	volatile String name1="Hii";
	static String name2 ="Ajay";
	
	
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public static String getName2() {
		return name2;
	}
	public static void setName2(String name2) {
		Employee_Serial.name2 = name2;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
}
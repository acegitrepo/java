
public class Consumer implements Runnable {
	MyList<String> customList;
	MyLock mylock;

	public Consumer(MyList<String> customList, MyLock mylock) {
		this.customList = customList;
		this.mylock = mylock;
	}

	@Override
	public void run() {
		while (true) {
			mylock.readLock();
			try {
				System.out.println("Pulling " + customList.get(0));
			} finally {
				mylock.readUnlock();
			}
		}
	}
}



public class CustomListLockingTest {
	public static void main(String[] args) {
		MyLock mylock = new MyLock();
		MyList<String> customList = new MyList<String>(10);
		Producer p = new Producer(customList,mylock);
		Consumer q = new Consumer(customList,mylock);
		
		new Thread(p).start();
		new Thread(q).start();
		new Thread(q).start();
	}
}

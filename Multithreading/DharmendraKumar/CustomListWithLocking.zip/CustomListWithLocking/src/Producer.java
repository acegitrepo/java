
public class Producer implements Runnable {
	MyList<String> customList;
	MyLock myLock;

	public Producer(MyList<String> customList, MyLock myLock) {
		this.customList = customList;
		this.myLock = myLock;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			myLock.writeLock();
			try{
				System.out.println("Pushing" + Thread.currentThread().getName()
						+ " String" + i);
				customList.put(Thread.currentThread().getName() + " String" + i);
			} finally {
				myLock.writeUnlock();
				
			}
		}
	}
}

import java.util.ArrayList;
import java.util.List;


public class MyList<E> {
	List<E> elementsList;
	int size;
	MyList(){
		elementsList = new ArrayList<E>();
	}
	public MyList(int i) {
		size = i;
		elementsList = new ArrayList<E>(i);
	}
	public synchronized E get(int index) {
		while (isEmpty()) {
			System.out
					.println("List is empty. Waiting for Producer to put.");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return elementsList.remove(index);
	}
	
	public synchronized void put( E element){
		while(size() >= size){
			System.out
			.println("List is full. Going to wait to get consumed.");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		elementsList.add(element);
	}
	
	public int size(){
		return elementsList.size();
	}
	
	public boolean isFull(){
		if(size() >= size){
			return true;
		}
			return false;
	}
	
	public boolean isEmpty(){
		return elementsList.isEmpty();
	}
}


import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;


public class MyLock {
	
	ReadWriteLock readWriteLock ;
	Lock readLock;
	Lock writeLock;
	Condition isFullCondition;
	Condition isEmptyCondition;
	private static final Lock lock = new ReentrantLock();
	
	public MyLock(){
		readWriteLock = new ReentrantReadWriteLock();
		readLock = readWriteLock.readLock();
		writeLock = readWriteLock.writeLock();
		isFullCondition = lock.newCondition();
		isEmptyCondition = lock.newCondition();

	}
	
	public Condition isFullCondition(){
		return isFullCondition;
	}
	
	public Condition isEmptyCondition(){
		return isEmptyCondition;
	}
	
	public void readLock(){
		readLock.lock();
	}
	
	public void writeLock(){
		writeLock.lock();
	}
	
	public void readUnlock(){
		readLock.unlock();
	}
	
	public void writeUnlock(){
		writeLock.unlock();
	}
}

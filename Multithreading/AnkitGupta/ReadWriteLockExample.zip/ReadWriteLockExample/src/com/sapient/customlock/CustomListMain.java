package com.sapient.customlock;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CustomListMain {

	CustomList list = new CustomList();

	private void reader(FileWriter filewriter) {
		ExecutorService es1 = Executors.newFixedThreadPool(10);
		for (int i = 0; i < 100; i++) {

			es1.submit(() -> {
				try {
					filewriter.write("Inside Reader  : \n");
					filewriter.write(list.get());
					filewriter.write(list.get());
					filewriter.write(" : Exiting Reader \n");

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			try {
				Thread.sleep(000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		es1.shutdown();
	}

	private void writer(FileWriter filewriter) throws InterruptedException {
		ExecutorService es = Executors.newFixedThreadPool(5);
		for (int i = 0; i < 100; i++) {
			final int value = i;
			es.submit(() -> {
				try {
					filewriter.write("Inside Reader" + value + "\n");
					list.add(value);
					filewriter.write(list.toString() + "\n");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});

		}
		es.shutdown();
	}

	public static void main(String[] args) throws InterruptedException, IOException {

		final CustomListMain readWriteDemo = new CustomListMain();
		File f = new File("C:\\Users\\agu226\\Desktop\\syso.txt");
		if (f.exists()) {
			f.delete();
		}
		f.createNewFile();
		final FileWriter filewriter = new FileWriter(f);
		Thread writer = new Thread(() -> {
			try {
				readWriteDemo.writer(filewriter);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		Thread reader = new Thread(() -> {
			try {
				readWriteDemo.reader(filewriter);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		writer.start();
		Thread.sleep(20);
		reader.start();

	}
}

package com.sapient.customlock;

import java.util.ArrayList;
import java.util.List;

import com.sapient.customlock.ReadAndWriteLock.ReadLock;
import com.sapient.customlock.ReadAndWriteLock.WriteLock;

/**
 * 
 * 1. Lock Exercise Implement a Custom List which has two methods a. add : No
 * Writer + No Reader b. get : No Write + No Write-Request
 * 
 * @author User
 *
 */
public class CustomList {
	List<Integer> list;
	ReadAndWriteLock lock = new ReadAndWriteLock();
	ReadLock rLock = lock.new ReadLock();
	WriteLock wLock = lock.new WriteLock();

	public CustomList() {
		this.list = new ArrayList<>();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return list.toString();
	}

	public void add(int x) {
		try {
			wLock.lock();
			list.add(x);
			//System.out.println(list);
		} finally {
			wLock.unlock();
		}
	}

	public int get(int index) {
		int value = 0;
		try {
			rLock.lock();
			value = list.get(index);
		} finally {
			rLock.unlock();
		}
		return value;
	}

	public int get() {
		int value = 0;
		try {
			rLock.lock();
			if (list.size() != 0) {
				value = list.get(list.size() - 1);
			}
		} finally {
			rLock.unlock();
		}
		return value;
	}
}

class ReadAndWriteLock {
	int writeLockCount = 0;
	int readLockCount = 0;

	class ReadLock {
		public void lock() {
			synchronized (this) {
				while (writeLockCount != 0) {
					try {
						wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			if (writeLockCount == 0) {
				readLockCount++;
			}

		}

		public void unlock() {
			synchronized (this) {
				if (readLockCount == 0) {
					throw new IllegalMonitorStateException();
				}
				readLockCount--;
				notifyAll();
				/*
				 * if (readLockCount == 0) { notifyAll(); }
				 */
			}

		}
	}

	class WriteLock {
		public void lock() {
			synchronized (this) {
				while (writeLockCount == 0 && readLockCount != 0) {
					try {
						wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			if (writeLockCount == 0 && readLockCount == 0) {
				writeLockCount++;
			}

		}

		public void unlock() {
			synchronized (this) {
				if (writeLockCount == 0) {
					throw new IllegalMonitorStateException();
				}
				writeLockCount--;
				notifyAll();
			}

		}
	}
}
package com.practise.ace;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

/**
 * this class demonstrates example of PriortyQueue class.
 * It store customer with random ids and names in priorty queue. It uses comparator to sort the ids in increasing order.
 *   
 * @author palam
 *
 */

public class PriorityQueueApp {

	public static void main(String[] args) {
		
		Comparator<Customer> cutomerComp = (Customer cust1, Customer cust2) -> {
				if(cust1.getId() > cust2.getId())
					return 1;
				if(cust1.getId() < cust2.getId())
					return -1;
				else
					return 0;
		};
		
		Queue<Customer> customers = new PriorityQueue<>(10, cutomerComp);
		
		populateCustomers(customers);
		
		processCustomers(customers);
		
	}
	
	private static void populateCustomers(Queue<Customer> customers){
		
		Random random = new Random();
		
		for(int i =1;i<=10 ;i++){
			int id  = random.nextInt(100);
			customers.add(new Customer(id, "SapeEmp"+id));
		}
	}
	
	private static void processCustomers(Queue<Customer> customers){
		
		while(true){
			Customer customer = customers.poll();
			
			if(customer == null) 
				break;
			System.out.println(customer);
			
		}
	}

}

class Customer {

	private int id;
	private String name;

	Customer() {
	}
	
	public Customer(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + "]";
	}

}


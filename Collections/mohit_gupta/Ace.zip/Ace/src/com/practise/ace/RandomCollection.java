package com.practise.ace;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class RandomCollection {

static int generateNumber(){
	Random r = new Random();
	
	
		int num= r.nextInt(10);
		return num;
	}
	

public static void main(String[] args) {
	//case 1
	
	Set<Integer> uniqueSet = new HashSet<Integer>(); 
	for(int i=0;i<15;i++)

	uniqueSet.add(generateNumber());
	


	System.out.println(""+uniqueSet);


//case 2
  
 		List<Integer> list = new ArrayList<Integer>();
 		for(int i=0;i<15;i++)
 			list.add(generateNumber());
 		Collections.sort(list,Comparator.reverseOrder());
 System.out.println(""+list);	
 
 
 
//case 3
	Set<Integer> sortedNum = new TreeSet<Integer>();
	
	for(int i=0;i<15;i++)
		sortedNum.add(generateNumber());
	
	System.out.println(""+sortedNum);

}



}

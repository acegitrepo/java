package com.practise.ace;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Employee implements Comparable<Employee>{

	private int empId;
	private String empName;

	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}

	@Override
	public int compareTo(Employee e) {
	
		if(this.empId > e.getEmpId())
			return 1;
		if(this.empId < e.getEmpId())
			return -1;
		else
			return 0;
	}

}
public class EmployeeCompareTest {

	public static void main(String[] args) {

		List<Employee> employeeList = new ArrayList<>();

		employeeList.add(new Employee(101, "Omer"));
		employeeList.add(new Employee(106, "Neha"));
		employeeList.add(new Employee(102,"Afreen"));
		employeeList.add(new Employee(104, "Parvez"));


		System.out.println("\nEmployee List before sorting :\n");

		for(Employee emp : employeeList){
			System.out.println(emp);
		}

		Collections.sort(employeeList);

		System.out.println("\nEmployee List after sorting :\n");

		for(Employee emp : employeeList){
			System.out.println(emp);
		}

	}
}

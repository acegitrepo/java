package com.practise.ace;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programe that take the name of five friends as input, Store them in LinkedList and remove the third element.
 * @author palam
 *
 */
public class LinkedListTest {

	public static void main(String[] args) {

		List<String> names = new LinkedList<String>();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter name of five friends : ");

		for(int i=1; i<=5;i++){
			String name = sc.next();
			names.add(name);
		}
		sc.close();


		System.out.println("Names of friends are : "+names);

		System.out.println("\nRemoving third friend...");
		
		names.remove(2); //Removing 3rd friend

		System.out.println("\nNames of friends are : "+names);
	}

}

package com.compare;

import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

public class PriorityQueueApp {

	public static void main(String[] args) {

		Queue<Customer> pq = new PriorityQueue<Customer>(new IdComparator());

		Customer c1 = new Customer(4, "Saurabh");
		Customer c2 = new Customer(2, "Ankur");
		Customer c3 = new Customer(3, "Abhishek");
		Customer c4 = new Customer(1, "Rahul");
		pq.add(c4);
		pq.add(c1);
		pq.add(c3);
		pq.add(c2);

		for (Customer c : pq) {
			System.out.println(c.getId() + " : " + c.getName());
			
		}
		/*while (!pq.isEmpty()) {
			Customer c = pq.remove();
			System.out.println(c.getId() + " : " + c.getName());
		}*/
	}

}

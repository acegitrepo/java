package com.compare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CompareTest {

	public static void main(String[] args) {

		
		Employee e1=new Employee(1, "Saurabh");
		Employee e2=new Employee(2, "Ankur");
		Employee e3=new Employee(3, "Piyush");
		Employee e4=new Employee(4, "Rahul");
		
		List<Employee> list=new ArrayList<Employee>();
		list.add(e4);list.add(e2);
		list.add(e3);list.add(e1);
		
		Collections.sort(list);
		System.out.println("Sorted By Id:");
		for (Employee e : list) {
			System.out.println(e.getId()+" : "+e.getName());
		}
		System.out.println("Sorted By Name:");
		Collections.sort(list, new NameComparator());
		for (Employee e : list) {
			System.out.println(e.getId()+" : "+e.getName());
		}
	}

}

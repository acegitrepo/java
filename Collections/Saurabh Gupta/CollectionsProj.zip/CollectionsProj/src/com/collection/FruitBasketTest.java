package com.collection;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class FruitBasketTest {

	public static void main(String[] args) {

		Fruit[] fruits = new Fruit[5];
		Scanner in = new Scanner(System.in);
		int x = 0;
		while (x < 5) {
			System.out.println("Enter fruit name:");
			String name = in.next();
			fruits[x] = new Fruit(name);
			x++;

		}
		in.close();
		List<Fruit> fruitList = FruitUtil.storeFruits(fruits);

		Collections.sort(fruitList);

		for (Fruit fruit : fruitList) {
			System.out.println(fruit.getName());
		}

		Fruit tempFrt = new Fruit("Apple");
		System.out.println(fruitList.contains(tempFrt));
	}

}

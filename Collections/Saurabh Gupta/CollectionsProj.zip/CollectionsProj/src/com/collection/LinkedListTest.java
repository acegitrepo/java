package com.collection;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class LinkedListTest {

	public static void main(String[] args) {

		int x=0;
		String[] names=new String[5];
		Scanner in=new Scanner(System.in);
		while(x<5){
			System.out.println("Enter name:");
			names[x]=in.next();
			x++;
		}
		in.close();
		List<String> list = new LinkedList<String>();
		for (String string : names) {
			list.add(string);
		}
		System.out.println("Removing 3rd name...");
		list.remove(2);
		System.out.println("Remaining friends are:");
		for (String string : list) {
			System.out.println(string);
		}
	}

}

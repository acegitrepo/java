package com.collection;
public class Fruit implements Comparable<Fruit>{

	private String name;

	public Fruit(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(Fruit frt) {
		return this.getName().compareTo(frt.getName());
	}
	
	@Override
	public boolean equals(Object ob) {
		
		Fruit anotherFruit = (Fruit)ob;
		return this.getName().equals(anotherFruit.getName());
		
	}
}

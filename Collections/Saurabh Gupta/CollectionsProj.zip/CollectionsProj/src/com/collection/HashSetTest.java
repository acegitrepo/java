package com.collection;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class HashSetTest {

	public static void main(String[] args) {

		int x = 0;
		Set<Integer> intSet=new HashSet<Integer>();
		Random r = new Random();
		while (intSet.size()<10) {
			intSet.add(r.nextInt(10));
			x++;
		}
		TreeSet<Integer> treeSet=new TreeSet<Integer>(intSet);
		intSet=treeSet.descendingSet();
		System.out.println("Decending Order:");
		for (Integer integer : intSet) {
			System.out.println(integer);
		}
		System.out.println("Assending Order:");
		for (Integer integer : treeSet) {
			System.out.println(integer);
		}
	}

}

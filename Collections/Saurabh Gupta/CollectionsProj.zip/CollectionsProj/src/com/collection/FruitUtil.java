package com.collection;

import java.util.Arrays;
import java.util.List;

public class FruitUtil {

	public static List<Fruit> storeFruits(Fruit[] frt) {

		List<Fruit> fruits = Arrays.asList(frt);// new ArrayList<Fruit>();

		return fruits;

	}
}

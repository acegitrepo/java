package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ALstExample {
	public static void main(String[] args) {
		List<Fat> fatlst = new ArrayList<>();
		fatlst.add(new Fat("Apple"));
		fatlst.add(new Fat("Banana"));
		fatlst.add(new Fat("Kiwi"));
		fatlst.add(new Fat("Papaya"));
		fatlst.add(new Fat("Orange"));
		Collections.sort(fatlst);
		for (Fat fat : fatlst) {
			System.out.println(fat.getName());
		}
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Fat Name: ");
		String input = in.nextLine();
		Fat inputfat = new Fat(input);
		if (Collections.binarySearch(fatlst, inputfat) < 0) {
			System.out.println("Not Present");
		} else {
			System.out.println("Present");
		}
		in.close();
	}
}

class Fat implements Comparable<Fat> {
	private String name;

	public Fat(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*
	 * @Override public boolean equals(Object obj) { if (!(obj instanceof
	 * Fat)) { return false; } else { Fat Fat = (Fat) obj; return
	 * this.name.equals(Fat.name); }
	 * 
	 * }
	 */

	@Override
	public int compareTo(Fat fat) {
		return this.name.compareTo(fat.getName());
	}

}

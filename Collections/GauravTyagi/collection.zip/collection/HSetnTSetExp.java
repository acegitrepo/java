package com.ace.collection;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class HSetnTSetExp{
	public static void main(String[] args) {
		Random random = new Random();
		Set<Integer> hset = new HashSet<>();
		Set<Integer> tSet = new TreeSet<>();
		for (int i = 0; i < 15; i++) {
			hset.add(Math.abs(random.nextInt() % 10));
			tSet.add(Math.abs(random.nextInt() % 10));
		}
		
		for (Integer x : hset) {
			System.out.println(x);
		}
		for (Integer x : tSet) {
			System.out.println(x);
		}
	}
}

package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmpCompare {

	public static void main(String[] args) {
		List<Emp> empLst = new ArrayList<Emp>();
		empLst.add(new Emp(103, "Mukul"));
		empLst.add(new Emp(101, "Gaurav"));
		empLst.add(new Emp(104, "Ayush"));
		empLst.add(new Emp(102, "Ankit"));
		Collections.sort(empLst,new NameComparator());
		for (Emp e : empLst) {
			System.out.println(e.toString());
		}
	}
}

class Emp implements Comparable<Emp> {
	Integer empId;
	String empName;
  
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "EmpId: " + empId + " Name :" + empName;
	}

	public Emp(Integer empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public int compareTo(Emp o) {
		return this.empId.compareTo(o.empId);
	}

}

class NameComparator implements Comparator<Emp> {

	@Override
	public int compare(Emp o1, Emp o2) {
		// TODO Auto-generated method stub
		return o1.empName.compareTo(o2.empName);
	}

}
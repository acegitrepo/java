package come.sapient.ace.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 * This class takes five names of fruits as input. Sort the alphabetically.
 * It also searches the fruit entered by user.  
 * @author palam
 *
 */
public class FruitBasketTest {

	public static void main(String[] args) {


		List<Fruit> fruits = new ArrayList<>();

		System.out.println("Enter the name of five fruits  : \n");

		Scanner sc = new Scanner(System.in);
		for(int i=1; i<=5;i++){

			String fruitName = sc.next();
			fruits.add(new Fruit(fruitName));
		}

		printFruits(fruits);

		sortFruits(fruits); //Sorting fruit names alphabetically

		System.out.println("\nAfrer sorting...\n");
		printFruits(fruits);

		System.out.println("\nEnter the fruit to be searched : \n");
		
		String fruitName  = sc.next();
		
		searchFruit(fruits, new Fruit(fruitName));
		
		sc.close();
	}

	private static void printFruits(List<Fruit> fruits){

		System.out.println("Fruits in the basket are "+fruits);

	}

	private static void sortFruits(List<Fruit> fruits){

		Comparator<Fruit> fruitComparator = (Fruit o1, Fruit o2) -> {
			return o1.getFruitName().compareTo(o2.getFruitName());
		};

		Collections.sort(fruits,fruitComparator);
	}

	private static void searchFruit(List<Fruit> fruits, Fruit fruit){
		
		if(fruits.contains(fruit))
			System.out.println(fruit +" is in the basket.");
		else
			System.out.println(fruit +" is not in the basket.");
	}
}
class Fruit{
	private String fruitName;


	public Fruit(String fruitName) {
		super();
		this.fruitName = fruitName;
	}

	public String getFruitName() {
		return fruitName;
	}

	public void setFruitName(String fruitName) {
		this.fruitName = fruitName;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fruitName == null) ? 0 : fruitName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fruit other = (Fruit) obj;
		if (fruitName == null) {
			if (other.fruitName != null)
				return false;
		} else if (!fruitName.equals(other.fruitName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return fruitName;
	}
}

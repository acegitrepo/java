package come.sapient.ace.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
/**
 * This class demonstrates example of HashSet and TreeSet. 
 * We need to store some random numbers and sort them using these two classes.
 * @author palam
 *
 */
public class SetTest {

	public SetTest() {
	}

	public static void main(String[] args) {

		sortUsingHashSet();
		sortUsingTreeSet();
	}

	private static void sortUsingHashSet(){

		HashSet<Integer> numbers = new HashSet<>();

		Random random = new Random();
		int num = 0;
		for(int i=1; i<=15; i++)
		{
			num = random.nextInt(10);
			numbers.add(num);
		}
		List<Integer> sortedNumbers = new ArrayList<Integer>(numbers);

		Comparator<Integer> comp = new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o1.compareTo(o2);
			}
		};

		System.out.println("Sorting numbers using HashSet\n");
		System.out.println("Numbers before sorting " +numbers);
		Collections.sort(sortedNumbers, comp);

		System.out.println("Numbers after sorting " +sortedNumbers);

	}

	private static void sortUsingTreeSet(){

		TreeSet<Integer> numbers = new TreeSet<>();

		Random random = new Random();
		int num = 0;
		for(int i=1; i<=15; i++)
		{
			num = random.nextInt(10);
			numbers.add(num);
		}
		System.out.println("\nSorted numbers using TreeSet" +numbers);

	}




}

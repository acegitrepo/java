package com.ace.collection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

public class PriorityQueueApp {
	public static void main(String[] args) {
		Queue<Customer> pq = new PriorityQueue<Customer>(new IDComparator());
		Customer c = new Customer((int) (Math.random() * 10), "Ayush");
		Customer c1 = new Customer((int) (Math.random() * 10), "Mukul");
		Customer c2 = new Customer((int) (Math.random() * 10), "Ankit");
		Customer c3 = new Customer((int) (Math.random() * 10), "Prem");

		pq.add(c);
		pq.add(c1);
		pq.add(c2);
		pq.add(c3);
		while (!pq.isEmpty()) {
			System.out.println(pq.poll().toString());
		}
		List<? super Number> list = new ArrayList<Number>();
		/*
		 * Iterator<Customer> itr = pq.iterator(); while (itr.hasNext()) {
		 * System.out.println(itr.next().toString()); }
		 */
	}
}

class Customer {
	private int id;
	private String name;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public Customer(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + "]";
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

class IDComparator implements Comparator<Customer> {

	@Override
	public int compare(Customer o1, Customer o2) {
		if (o1.getId() > o2.getId()) {
			return 1;
		} else if (o1.getId() < o2.getId()) {
			return -1;
		} else {
			return 0;
		}
	}

}
package com.ace.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayListExample {
	public static void main(String[] args) {
		List<Fruit> fruitList = new ArrayList<>();
		fruitList.add(new Fruit("Apple"));
		fruitList.add(new Fruit("Banana"));
		fruitList.add(new Fruit("Kiwi"));
		fruitList.add(new Fruit("Papaya"));
		fruitList.add(new Fruit("Orange"));
		Collections.sort(fruitList);
		for (Fruit fruit : fruitList) {
			System.out.println(fruit.getName());
		}
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Fruit Name: ");
		String input = in.nextLine();
		Fruit inputFruit = new Fruit(input);
		if (Collections.binarySearch(fruitList, inputFruit) < 0) {
			System.out.println("Not Present");
		} else {
			System.out.println("Present");
		}
		in.close();
	}
}

class Fruit implements Comparable<Fruit> {
	private String name;

	public Fruit(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*
	 * @Override public boolean equals(Object obj) { if (!(obj instanceof
	 * Fruit)) { return false; } else { Fruit fruit = (Fruit) obj; return
	 * this.name.equals(fruit.name); }
	 * 
	 * }
	 */

	@Override
	public int compareTo(Fruit fruit) {
		return this.name.compareTo(fruit.getName());
	}

}

package com.java.ace.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Stack;

public class ArrayListSortDemo {

	
	public static void main(String[] args) {
		List<Fruit> fruits = new ArrayList<>(); 
		ListUtil.addElements(fruits);
		ListUtil.printList(fruits);
		System.out.println("List after sorting");
		Collections.sort(fruits,(Fruit o1, Fruit o2) -> 
        {
            int v = o1.name.compareTo(o2.name);
            return v;           
         }    
		);
		ListUtil.printList(fruits);
		Stack<Integer> abc = new Stack<>();
		System.out.println("Is kiwi present in Fruit List" + ListUtil.isElementAvailable(fruits, new Fruit("Kiwi")));
	}
	
}

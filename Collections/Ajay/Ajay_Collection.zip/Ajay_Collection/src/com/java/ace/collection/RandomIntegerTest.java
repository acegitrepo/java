package com.java.ace.collection;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class RandomIntegerTest {
	public static void main(String[] args) {
		Integer intObj = null;
		Set<Integer> numbers = new HashSet<Integer>();
		Set<Integer> presortedNumbers = new TreeSet<Integer>();
		Set<Integer> reverseNumbers = new TreeSet<Integer>();

		for (int i = 0; i < 15; i++) {
			i = RandomGenerator.getIntBetween(0, 10);
			numbers.add(i);
			presortedNumbers.add(i);
		}
		System.out.println("Unsorted List :" + numbers);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		TreeSet sortedSet = new TreeSet(numbers);
		System.out.println("Sorted List :" + sortedSet);

/**		reverseNumbers = new TreeSet<Integer>(new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o2.compareTo(o1);
			}
		});
		reverseNumbers.addAll(numbers);
		System.out.println("Sorted Set: " + reverseNumbers);
**/
	}

}

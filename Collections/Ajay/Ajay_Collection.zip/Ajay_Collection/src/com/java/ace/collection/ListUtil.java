package com.java.ace.collection;

import java.util.List;

public class ListUtil {

	
	public static void addElements(List<Fruit> fruits){
		fruits.add(new Fruit("Apple"));
		fruits.add(new Fruit("Grape"));
		fruits.add(new Fruit("Kiwi"));
		fruits.add(new Fruit("Pear"));
		fruits.add(new Fruit("Mango"));
	}
	
	public static void printList(List<Fruit> fruits){
		for(Fruit fruit: fruits){
			System.out.println(fruit.name);
		}
	}
	
	public static boolean isElementAvailable(List<Fruit> fruits, Fruit fruit){
		return fruits.contains(fruit);
	}
}

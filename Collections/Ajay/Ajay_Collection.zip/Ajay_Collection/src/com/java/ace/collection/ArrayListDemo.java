package com.java.ace.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo {

	
	
	public static void main(String[] args) {
		List<Fruit> fruits = new ArrayList<>(); 
		ListUtil.addElements(fruits);
		ListUtil.printList(fruits);
		
		List<Employee> employees = new ArrayList<>();
		Employee.initList(employees);
		Collections.sort(employees, (Employee e1, Employee e2) -> {
			return e1.id-e2.id;
		});
		
	}
}

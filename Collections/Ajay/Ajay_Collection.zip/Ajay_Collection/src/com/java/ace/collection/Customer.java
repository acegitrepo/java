package com.java.ace.collection;

import java.util.Comparator;

public class Customer implements Comparable {
	String name;
	Integer id;

	public Customer() {
	}

	public Customer(String name, Integer id) {
		this.name = name;
		this.id = id;
	}

	@Override
	public String toString() {
		return "Customer{" + "name=" + name + ", id=" + id + '}';
	}
	
	
	public int compareTo(Object o) {
		return this.id.compareTo(((Customer)o).id);
	}

	static class ComparatorId implements Comparator<Customer> {
		@Override
		public int compare(Customer obj1, Customer obj2) {
			
			return ((Customer)obj1).id.compareTo(((Customer)obj2).id);
		}
	}

}

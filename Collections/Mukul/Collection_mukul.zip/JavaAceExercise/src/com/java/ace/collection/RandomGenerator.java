package com.java.ace.collection;

import java.util.Random;

public class RandomGenerator {
	public static int getIntBetween(int lower, int upper) {
		return new Random().nextInt(upper - lower) + lower;
	}
	
	public static long getLongBetween(int lower, int upper) {
		return (long) (new Random().nextInt(upper - lower) + lower);
	}
	
}

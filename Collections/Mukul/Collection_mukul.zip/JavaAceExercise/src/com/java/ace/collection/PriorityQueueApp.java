package com.java.ace.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueApp {
	public static void main(String[] args) {

		Customer emp1 = new Customer("sam", RandomGenerator.getIntBetween(1,
				1000));
		Customer emp2 = new Customer("amy", RandomGenerator.getIntBetween(1,
				1000));
		Customer emp3 = new Customer("brad", RandomGenerator.getIntBetween(1,
				1000));

		Queue<Customer> list = new PriorityQueue<Customer>();
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);

		System.out.println("list Before sorting : \n" + list);

		List<Customer> clist = new ArrayList<Customer>(list);

		Collections.sort(clist, new Customer.ComparatorId());
		System.out
				.println("\nlist after sorting on basis of id(ascending order), "
						+ "using static inner class : \n" + list);
		
		List l = new ArrayList<String>();
		List<String> l1 = new ArrayList();

	}
}

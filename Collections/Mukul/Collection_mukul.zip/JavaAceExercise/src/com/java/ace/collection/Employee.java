package com.java.ace.collection;

import java.util.List;

public class Employee implements Comparable<Employee> {
	public String name;
	public int id;
	
	
	public Employee(String name, int id){
		this.name = name;
		this.id = id;
	}
	
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name);
	}
	
	public static void initList(List<Employee> employees){
		employees.add(new Employee("mukul", 125416));
		employees.add(new Employee("ankit", 125417));
		employees.add(new Employee("prem", 125414));
		employees.add(new Employee("ayush", 125412));
		
	}

}

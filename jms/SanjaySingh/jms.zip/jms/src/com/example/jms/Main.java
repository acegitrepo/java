package com.example.jms;

import java.net.URISyntaxException;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;

public class Main {

	public static void main(String[] args) throws URISyntaxException, Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		try {

			SpringJmsOrderProducer springJmsProducer = (SpringJmsOrderProducer) context
					.getBean("SpringJmsOrderProducer");

			JmsTemplate jmsTemplateOrderQueue = (JmsTemplate) context.getBean("jmsTemplateOrderQueue");

			springJmsProducer.setJmsTemplate(jmsTemplateOrderQueue);

			Order order = new Order(1, 10, "Queue", 10);
			System.out.println("Sending order " + order);
			springJmsProducer.sendMessage(order);

			SpringJmsOrderConsumer springJmsConsumer = (SpringJmsOrderConsumer) context
					.getBean("SpringJmsOrderConsumer");
			springJmsConsumer.setJmsTemplate(jmsTemplateOrderQueue);
			Order recievedOrder = springJmsConsumer.receiveMessage();
			recievedOrder.setOrderStatus("Processed");

			System.out.println("Consumer receives " + recievedOrder.toString());

			JmsTemplate jmsTemplateExecutedOrderQueue = (JmsTemplate) context.getBean("jmsTemplateExecutedOrderQueue");
			springJmsProducer.setJmsTemplate(jmsTemplateExecutedOrderQueue);
			springJmsProducer.sendMessage(order);

		} finally {
			context.close();
		}
	}
}

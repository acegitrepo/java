package com.example.jms;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;



public class OrderMessageConvertor implements MessageConverter {
	


	public Message toMessage(Object object, Session session)
			throws JMSException, MessageConversionException {		
		Order order = (Order) object;
		MapMessage message = session.createMapMessage();
		message.setLong("orderId", order.getOrderId());
		message.setInt("orderQuantity", order.getOrderQuantity());
		message.setString("orderStatus", order.getOrderStatus());
		message.setInt("price", order.getPrice());
		return message;
	}

	public Object fromMessage(Message message) throws JMSException,
			MessageConversionException {
		MapMessage mapMessage = (MapMessage) message;
		Order person = new Order(mapMessage.getLong("orderId"), mapMessage.getInt("orderQuantity"),mapMessage.getString("orderStatus"),mapMessage.getInt("price"));
		return person;
	}



}

package com.example.jms;

import javax.jms.JMSException;

import org.springframework.jms.core.JmsTemplate;

public class SpringJmsOrderConsumer {
	

	private JmsTemplate jmsTemplate;

	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
	
	public Order receiveMessage() throws JMSException {
		Order person = (Order) getJmsTemplate().receiveAndConvert();
		return person;	
	}
}

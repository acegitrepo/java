package com.factoryPattern;

public class InstitutionalPlan extends Plan {
	public void getRate(){   
        rate=5.50;  
   }   

}

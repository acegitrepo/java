package com.factoryPattern;

import java.util.NavigableMap;

public class DomesticPlan extends Plan{
	 public void getRate(){  
         rate=3.50;  
         
         NavigableMap
    }  

}

package command;

public interface Reciever{
	void openFile();
	void writeFile();
	void readFile();
}

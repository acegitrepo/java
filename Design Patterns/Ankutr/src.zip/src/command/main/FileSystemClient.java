package command.main;

import command.Command;
import command.Reciever;
import command.impl.Invoker;
import command.impl.OpenFileCommand;
import command.impl.ReadFileCommand;
import command.impl.WindowsFileSystemReceiver;
import command.impl.WriteFileCommand;

public class FileSystemClient {
	public static void main(String[] args) {
		Reciever rc;
        rc = new WindowsFileSystemReceiver();
		Command comm = new OpenFileCommand(rc); 
		Invoker inv = new Invoker(comm);
		inv.execute();
		comm = new WriteFileCommand(rc);
		inv = new Invoker(comm);
		inv.execute();
		comm = new ReadFileCommand(rc);
		inv = new Invoker(comm);
		inv.execute();
	}
}

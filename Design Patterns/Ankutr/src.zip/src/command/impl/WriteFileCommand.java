package command.impl;

import command.Command;
import command.Reciever;

public class WriteFileCommand implements Command {
	private Reciever reciever;
	public WriteFileCommand(Reciever rc){
		this.reciever=rc;
	}
	@Override
	public void execute() {
		this.reciever.writeFile();
		
	}
}

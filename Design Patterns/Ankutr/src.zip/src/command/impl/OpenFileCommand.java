package command.impl;

import command.Command;
import command.Reciever;

public class OpenFileCommand  implements Command {
	private Reciever reciever;
	public OpenFileCommand(Reciever rc){
		this.reciever=rc;
	}
	@Override
	public void execute() {
		this.reciever.openFile();
		
	}

}

package command.impl;

import command.Reciever;

public class UnixFileSystemReceiver implements Reciever{

	@Override
	public void openFile() {
		System.out.println("Opening file in unix OS");
	}

	@Override
	public void writeFile() {
		System.out.println("writing  file in unix OS");		
	}

	@Override
	public void readFile() {
		System.out.println("reading file in unix OS");
		
	}

}

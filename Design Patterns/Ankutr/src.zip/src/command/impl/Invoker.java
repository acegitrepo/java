package command.impl;

import command.Command;

public class Invoker {
	public Command command;
	public Invoker(Command cm){
		this.command =cm;
	}
public void execute(){
	this.command.execute();
}
}

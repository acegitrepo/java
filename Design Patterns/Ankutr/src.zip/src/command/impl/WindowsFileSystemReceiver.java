package command.impl;

import command.Reciever;

public class WindowsFileSystemReceiver implements Reciever {

	@Override
	public void openFile() {
		System.out.println("Opening file in windows OS");
		
	}

	@Override
	public void writeFile() {
		System.out.println("Writing file in windows OS");
		
	}

	@Override
	public void readFile() {
		System.out.println("reading file in windows OS");
		
	}

}

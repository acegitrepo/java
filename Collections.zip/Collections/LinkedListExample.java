package com.ace.collection;

import java.util.LinkedList;
import java.util.List;

public class LinkedListExample {
	public static void main(String[] args) {
		List<String> friendList = new LinkedList<String>();
		friendList.add("Ankit");
		friendList.add("Mukul");
		friendList.add("Ayush");
		friendList.add("Jai");
		
		System.out.println("Before Removing"+friendList );

		friendList.remove(3);
		
		System.out.println("After Removing"+friendList );
		

	}
}

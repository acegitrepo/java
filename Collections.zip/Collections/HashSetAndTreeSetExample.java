package com.ace.collection;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class HashSetAndTreeSetExample {
	public static void main(String[] args) {
		Random random = new Random();
		Set<Integer> hashSet = new HashSet<>();
		Set<Integer> treeSet = new TreeSet<>();
		for (int i = 0; i < 15; i++) {
			hashSet.add(Math.abs(random.nextInt() % 10));
			treeSet.add(Math.abs(random.nextInt() % 10));
		}
		
		for (Integer x : hashSet) {
			System.out.println(x);
		}
		for (Integer x : treeSet) {
			System.out.println(x);
		}
	}
}

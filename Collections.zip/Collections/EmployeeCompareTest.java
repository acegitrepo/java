package com.ace.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmployeeCompareTest {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(new Employee(103, "Mukul"));
		empList.add(new Employee(101, "Gaurav"));
		empList.add(new Employee(104, "Ayush"));
		empList.add(new Employee(102, "Ankit"));
		Collections.sort(empList,new NameComparator());
		for (Employee e : empList) {
			System.out.println(e.toString());
		}
	}
}

class Employee implements Comparable<Employee> {
	Integer empId;
	String empName;
  
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "EmpId: " + empId + " Name :" + empName;
	}

	public Employee(Integer empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public int compareTo(Employee o) {
		return this.empId.compareTo(o.empId);
	}

}

class NameComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.empName.compareTo(o2.empName);
	}

}
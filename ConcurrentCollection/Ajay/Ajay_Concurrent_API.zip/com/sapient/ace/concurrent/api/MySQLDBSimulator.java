package com.sapient.ace.concurrent.api;

import java.util.concurrent.CountDownLatch;

public class MySQLDBSimulator extends AbstractDBSimulator{

	public MySQLDBSimulator(CountDownLatch latch) {
		super(latch);
	}
	@Override
	protected long getFetchingTime() {
		return 5000;
	}
	@Override
	protected String getDBName() {
		return "MYSql";
	}

}

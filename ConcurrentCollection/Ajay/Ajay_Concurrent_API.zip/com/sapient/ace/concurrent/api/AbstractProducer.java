package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;

public abstract class AbstractProducer<T> implements Runnable {

	private BlockingQueue<T> queue;

	public AbstractProducer(BlockingQueue<T> queue) {
		super();
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			T t = produceTask();
			System.out.println("Task produced:: {}"+t);
			try {
				queue.put(t);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	protected abstract T produceTask();

}

package com.sapient.ace.concurrent.api;

public interface DBSimulator {
	
	public void fetchData();

}

package com.sapient.ace.concurrent.api;

import java.time.LocalTime;
import java.util.concurrent.BlockingQueue;

public class StringProducer extends AbstractProducer<String>{

	public StringProducer(BlockingQueue<String> queue) {
		super(queue);
	}

	@Override
	protected String produceTask() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "ajay_produce_"+LocalTime.now();
	}

}

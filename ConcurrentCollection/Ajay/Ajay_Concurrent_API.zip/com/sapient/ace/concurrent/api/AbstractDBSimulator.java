package com.sapient.ace.concurrent.api;

import java.util.concurrent.CountDownLatch;

public abstract class AbstractDBSimulator implements DBSimulator , Runnable{
	
	private CountDownLatch latch;
	

	public AbstractDBSimulator(CountDownLatch latch) {
		super();
		this.latch = latch;
	}

	@Override
	public void fetchData() {
		System.out.println("Data fetching from DB::" + getDBName());
	}

	@Override
	public void run() {
		try {
			fetchData();
			Thread.sleep(getFetchingTime());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}finally{
			System.out.println("DATA fetched from the DB::"+getDBName());
			latch.countDown();
		}
		
	}

	protected abstract long getFetchingTime();

	protected abstract String getDBName();

}

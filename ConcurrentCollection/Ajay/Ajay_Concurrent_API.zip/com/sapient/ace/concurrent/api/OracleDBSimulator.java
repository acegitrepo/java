package com.sapient.ace.concurrent.api;

import java.util.concurrent.CountDownLatch;

public class OracleDBSimulator extends AbstractDBSimulator {

	public OracleDBSimulator(CountDownLatch latch) {
		super(latch);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected long getFetchingTime() {
		return 2000;
	}

	@Override
	protected String getDBName() {
		return "Oracle 10G";
	}

}

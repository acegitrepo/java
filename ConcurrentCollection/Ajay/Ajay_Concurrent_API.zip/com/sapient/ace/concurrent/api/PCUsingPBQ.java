package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

public class PCUsingPBQ {
	
	public static void main(String args []){
		final BlockingQueue<String> abq = new PriorityBlockingQueue<>(10);
		Thread prodcuer = new Thread(new StringProducer(abq));
		Thread consumer = new Thread(new StringConsumer(abq));
		prodcuer.start();
		consumer.start();
	}



}

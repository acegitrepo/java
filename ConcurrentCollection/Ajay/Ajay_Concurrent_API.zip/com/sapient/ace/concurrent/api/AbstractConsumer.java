package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;

public abstract class AbstractConsumer<T> implements Runnable {

	private BlockingQueue<T> queue;

	@Override
	public void run() {
		while (true) {
			T t = null;
			try {
				t = queue.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			consumeTask(t);
			System.out.println("Task Consumed " + t);
			
		}
	}

	public AbstractConsumer(BlockingQueue<T> queue) {
		super();
		this.queue = queue;
	}

	protected abstract void consumeTask(T t);
}

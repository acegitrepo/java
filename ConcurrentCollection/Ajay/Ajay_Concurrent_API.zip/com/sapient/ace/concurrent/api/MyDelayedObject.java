package com.sapient.ace.concurrent.api;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class MyDelayedObject implements Delayed {

	private String str;
	private long delay;

	@Override
	public int compareTo(Delayed o) {
		if (this.delay < ((MyDelayedObject) o).delay) {
			return -1;
		}
		if (this.delay > ((MyDelayedObject) o).delay) {
			return 1;
		}
		return 0;
	}

	public MyDelayedObject(String str, long delay) {
		super();
		this.str = str;
		this.delay = System.currentTimeMillis() + delay;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long diff = delay - System.currentTimeMillis();
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

}

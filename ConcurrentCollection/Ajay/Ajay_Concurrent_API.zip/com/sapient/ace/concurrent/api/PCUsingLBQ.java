package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class PCUsingLBQ {

	
	public static void main(String args []){
		final BlockingQueue<String> abq = new LinkedBlockingQueue<>();
		Thread prodcuer = new Thread(new StringProducer(abq));
		Thread consumer = new Thread(new StringConsumer(abq));
		prodcuer.start();
		consumer.start();
	}

}

package com.sapient.ace.concurrent.api;

import java.util.concurrent.CountDownLatch;

public class PostgresqlDBSimulator extends AbstractDBSimulator {

	public PostgresqlDBSimulator(CountDownLatch latch) {
		super(latch);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected long getFetchingTime() {
		return 8000;
	}

	@Override
	protected String getDBName() {
		return "Postgresql";
	}

}

package com.sapient.ace.concurrent.api;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;

public class DelayProducer extends AbstractProducer<MyDelayedObject>{
	
	private Random random = new Random();

	public DelayProducer(BlockingQueue<MyDelayedObject> queue) {
		super(queue);
	}

	@Override
	protected MyDelayedObject produceTask() {
		MyDelayedObject delayElement = new MyDelayedObject	(UUID.randomUUID()
				.toString(), random.nextInt(1000));
		return delayElement;
	}

}

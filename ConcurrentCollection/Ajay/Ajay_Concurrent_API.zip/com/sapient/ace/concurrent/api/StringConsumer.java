package com.sapient.ace.concurrent.api;

import java.time.LocalTime;
import java.util.concurrent.BlockingQueue;

public class StringConsumer extends AbstractConsumer<String>{

	public StringConsumer(BlockingQueue<String> queue) {
		super(queue);
	}

	@Override
	protected void consumeTask(String t) {
		t = t+"_consumed_at_"+LocalTime.now();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

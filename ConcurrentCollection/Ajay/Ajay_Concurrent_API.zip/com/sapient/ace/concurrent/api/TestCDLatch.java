package com.sapient.ace.concurrent.api;

import java.util.concurrent.CountDownLatch;

public class TestCDLatch {
	
	public static void main(String args[]){
		
		final CountDownLatch clatch = new CountDownLatch(3);
		Thread OracleDB = new Thread(new OracleDBSimulator(clatch));
		Thread mysqlDB = new Thread(new MySQLDBSimulator(clatch));
		Thread postgresDB = new Thread(new PostgresqlDBSimulator(clatch));
		OracleDB.start();
		mysqlDB.start();
		postgresDB.start();
		
		
		try {
			clatch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			System.out.println("DATA fetched from all DBs.");
		}
		
		
	}
	
	

}

package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;

public class DelayConsumer extends AbstractConsumer<MyDelayedObject>{

	public DelayConsumer(BlockingQueue<MyDelayedObject> queue) {
		super(queue);
	}

	@Override
	protected void consumeTask(MyDelayedObject t) {
		System.out.println("delayed object consumed::"+ t);
	}

}

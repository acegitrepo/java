package com.sapient.ace.concurrent.api;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;

public class PCUsingDQ {
	
	public static void main(String args []){
		final BlockingQueue<MyDelayedObject> abq = new DelayQueue<MyDelayedObject>();
		Thread prodcuer = new Thread(new DelayConsumer(abq));
		Thread consumer = new Thread(new DelayProducer(abq));
		prodcuer.start();
		consumer.start();
	}



}

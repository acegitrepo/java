package com.sapient.ace.concurrent.api;

public class MySeamaphore {

	public MySeamaphore(int count) {
		super();
		this.count = count;
	}

	private volatile int count;

	public synchronized void acquire() throws InterruptedException {
		if (count > 0) {
			count--;
		} else {
			wait();
			count--;
		}
	}

	public synchronized void release() {
		count++;

		if (count > 0)
			notifyAll();
	}
}

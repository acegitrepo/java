package com.sapient.ace.test;

public class MyTest {

	public static void main(String[] args) {
		
		String a = "java";
		String b = "programming";
		String c = a+b;
		String d = "java programming";
		String e = "java programming";
		System.out.println(d == e); 
	}	

}

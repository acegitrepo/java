package com.sapient.ace.threadpool;

public interface IThreadPool {
	
	public void  execute(Runnable runnable);
	
	public void shutdown();
	
	public boolean isShutdownInitiated();
}

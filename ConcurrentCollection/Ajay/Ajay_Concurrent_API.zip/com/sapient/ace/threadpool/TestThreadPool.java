package com.sapient.ace.threadpool;

import java.util.Random;

public class TestThreadPool {

	public static void main(String args[]) {
		IThreadPool myPool = new ACEThreadPool(5);
		for (int i = 1; i < 10; i++) {
			myPool.execute(new MyTask(i));
		}
	}

}

class MyTask implements Runnable {
	private int taskNo;

	public MyTask(int number) {
		taskNo = number;
	}

	@Override
	public void run() {
		Random rand = new Random();
		int time = taskNo * 1000 * rand.nextInt(10);
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Task number " + taskNo + " executed for millisecconds " + time);
	}
}

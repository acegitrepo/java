package com.sapient.ace.threadpool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public final class ACEThreadPool implements IThreadPool {

	final private BlockingQueue<Runnable> tasks;
	private boolean shutdownThreadPool = false;

	public ACEThreadPool(final int size) {
		tasks = new LinkedBlockingDeque<>(size);
		for (int i = 0; i < size; i++) {
			final Thread newWorker = new WorkerThread(tasks, this);
			newWorker.setName(this.getClass().getSimpleName() + "--Thread No : " + i);
			newWorker.start();
		}
	}

	@Override
	public void execute(Runnable task) {
		try {
			tasks.put(task);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void shutdown() {
		this.shutdownThreadPool = true;

	}

	public boolean isShutdownInitiated() {
		return this.shutdownThreadPool;
	}

	private static class WorkerThread extends Thread {

		private BlockingQueue<Runnable> tasks;
		private IThreadPool threadPool;

		private WorkerThread(BlockingQueue<Runnable> tasks, IThreadPool threadPool) {
			this.tasks = tasks;
			this.threadPool = threadPool;
		}

		@Override
		public void run() {
			while (true) {
				try {
					Runnable task = tasks.take();
					task.run();
					System.out.println("Thread no "+Thread.currentThread().getName()+" is running");

					if (threadPool.isShutdownInitiated() && tasks.isEmpty()) {
						this.interrupt();
						Thread.sleep(1);
					}

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}

}

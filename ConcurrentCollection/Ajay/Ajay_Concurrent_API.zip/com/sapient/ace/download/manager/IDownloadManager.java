package com.sapient.ace.download.manager;

public interface IDownloadManager {

	void startDownload(Runnable task);
}

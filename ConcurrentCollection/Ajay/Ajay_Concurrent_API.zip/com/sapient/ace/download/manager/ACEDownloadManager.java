package com.sapient.ace.download.manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ACEDownloadManager implements IDownloadManager {

	private ExecutorService service = Executors.newFixedThreadPool(5);

	@Override
	public void startDownload(Runnable task) {
		service.execute(task);
	}

}

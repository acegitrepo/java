package com.sapient.ace.download.manager;

public class TestDownloadManager {

	public static void main(String arg[]) {

		final IDownloadManager manager = new ACEDownloadManager();

		for (int i = 0; i < 2; i++) {
			final IDownlaodTask task = new ACEDownloadTask("TASK_NO_" + i);
			manager.startDownload((Runnable) task);

		}
	}

}

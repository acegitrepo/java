package com.sapient.ace.download.manager;

import java.util.Random;

public class ACEDownloadTask implements IDownlaodTask, Runnable {

	private int downloadStatus = 0;

	private String taskID;

	public ACEDownloadTask(String taskID) {
		this.taskID = taskID;
	}

	@Override
	public int getDownloadStatus() {
		return this.downloadStatus;
	}

	@Override
	public void run() {
		System.out.println("Starting download of task " + getTaskId());
		showDownloadProgress(this);

		Random rand = new Random();
		for (int i = 0; i < 10; i++) {
			downloadStatus = downloadStatus + 10;
			try {
				Thread.sleep(1000 * rand.nextInt(5));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void showDownloadProgress(ACEDownloadTask aceDownloadTask) {
		Thread t = new Thread(new DownloadProgress(aceDownloadTask));
		t.start();

	}

	@Override
	public void download() {
		// TODO Auto-generated method stub

	}

	public static class DownloadProgress implements Runnable {

		private IDownlaodTask task;

		public DownloadProgress(IDownlaodTask task) {
			this.task = task;
		}

		@Override
		public void run() {
			while (task.getDownloadStatus() != 100) {
				System.out.println(
						"Task Number " + task.getTaskId() + "has been downloaded " + task.getDownloadStatus() + "%");
			}

		}

	}

	@Override
	public String getTaskId() {
		// TODO Auto-generated method stub
		return this.taskID;
	}

}

package com.sapient.ace.download.manager;

class Worker{
	private int workerId;
	private String workerName;
	public Worker(int workerId,String workerName){
		this.workerId=workerId;
		this.workerName=workerName;
	}
	/*@Override
	public String toString1() {
		return "Worker [workerId=" + workerId + ", workerName=" + workerName
				+ "]";
	}*/
	@Override
	public String toString() {
		return "Worker [workerId=" + workerId + ", workerName=" + workerName
				+ "]";
	}
	@Deprecated
	public void printWorker(){
		System.out.println(workerId);
		System.out.println(workerName);
	}
}

public class AnnotationWorkerTest {

	public static void main(String[] args) {
		Worker worker=new Worker(101, "Ajay");
		System.out.println(worker);
		worker.printWorker();

	}

}

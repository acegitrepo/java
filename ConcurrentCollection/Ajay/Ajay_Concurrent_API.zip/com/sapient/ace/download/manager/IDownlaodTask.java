package com.sapient.ace.download.manager;

public interface IDownlaodTask {
	
	int getDownloadStatus();
	
	void download();
	
	String getTaskId();

}

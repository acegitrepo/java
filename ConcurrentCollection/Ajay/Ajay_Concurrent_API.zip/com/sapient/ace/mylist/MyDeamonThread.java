package com.sapient.ace.mylist;

public class MyDeamonThread {

	public static void main(String args[]) {

		Thread t = new Thread(new FinallyDeamonThread());
		t.setDaemon(true);
		t.start();
		
		try {
			Thread.currentThread().sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
		System.out.println("done");

	}

	static final class FinallyDeamonThread implements Runnable {

		@Override
		public void run() {
			try {
				for (int i = 0; i < 10; i++) {
					System.out.println("Testing deamong");
					Thread.currentThread().sleep(1000); 
				}
			} catch (InterruptedException e) {
				System.out.println("is error?");
			} finally {
				System.out.println("finally");
			}
		}

	}

}

package com.sapient.ace.mylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmployeeComparteTest {
	
	public static void main(String args[]){
		List<Employee> emps = new ArrayList<>();
		emps.add(new Employee(389, "Ajtttay"));
		emps.add(new Employee(1389, "gAjuiay"));
		emps.add(new Employee(38449, "Ajay"));
		emps.add(new Employee(3897, "Ajgay"));
		emps.add(new Employee(3829, "dAjay"));
		emps.add(new Employee(38900, "qAjay"));
		
		System.out.println("before sorting:"+emps);
		Collections.sort(emps);
		System.out.println("after sorting by id:"+emps);
		
		Collections.sort(emps,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpName().compareTo(o2.getEmpName());
			}
		});
		
		System.out.println("after sorting by name:"+emps);
		
	}
	
	

}

class Employee implements Comparable<Employee>{
	private Integer empID;
	private String empName;
	public Employee(Integer empID, String empName) {
		super();
		this.empID = empID;
		this.empName = empName;
	}
	public Integer getEmpID() {
		return empID;
	}
	public void setEmpID(Integer empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public int compareTo(Employee o) {
		return this.empID.compareTo(o.empID);
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + "]";
	}
	
	
	
}


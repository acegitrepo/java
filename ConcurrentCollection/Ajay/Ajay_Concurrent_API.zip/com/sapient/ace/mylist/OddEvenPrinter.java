package com.sapient.ace.mylist;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class OddEvenPrinter {

	public static void main(String args[]) {
		
		int noToPrint = 20;
		Lock lock = new ReentrantLock();
		Thread OPrinter = new Thread(new OddNoPrinter(noToPrint,lock));
		Thread EPrinter = new Thread(new EvenNoPrinter(noToPrint,lock));
		
		OPrinter.start();
		EPrinter.start();
	}

}

class OddNoPrinter implements Runnable {

	private volatile boolean printOdd;
	private volatile int maxLimit;
	private int initialNO = 1;
	private Lock lock ;

	public OddNoPrinter(int maxLimit, Lock lock) {
		super();
		this.printOdd = printOdd;
		this.maxLimit = maxLimit;
		this.lock = lock;
	}

	@Override
	public void run() {
		while(maxLimit >=0){
			if(maxLimit%2==0){
				try {
					lock.lock();
					lock.wait();
				} catch (InterruptedException e) {
				}
			}
			System.out.println(initialNO);
			this.initialNO = this.initialNO+ 2;
			maxLimit--;
			lock.notifyAll();
			lock.unlock();
		}

	}

}

class EvenNoPrinter implements Runnable {

	private volatile boolean printOdd;
	private Lock lock;
	private volatile int maxLimit;
	private int initalNo = 0;

	public EvenNoPrinter(int maxLimit, Lock lock) {
		super();
		this.printOdd = printOdd;
		this.maxLimit = maxLimit;
		this.lock = lock;
	}

	@Override
	public void run() {
		while (maxLimit >=0) {
			if(!(maxLimit%2==0)){
				try {
					lock.lock();
					lock.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
			System.out.println(initalNo);
			this.initalNo = this.initalNo + 2;
			maxLimit--;
			lock.notifyAll();
			lock.unlock();
		}

	}

}

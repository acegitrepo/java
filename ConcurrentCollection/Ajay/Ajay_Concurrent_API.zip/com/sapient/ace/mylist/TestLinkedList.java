package com.sapient.ace.mylist;

import java.util.LinkedList;
import java.util.List;

public class TestLinkedList {

	public static void main(String args[]) {
		List<String> list = new LinkedList<>();
		list.add("Ajay");
		list.add("vijay");
		list.add("Raju");
		list.add("chandan");
		list.add("saurabh");
		
		System.out.println("Before removing friends:"+list);
		
		System.out.println("Remove 3rd peson");
		list.remove(2);
		
		System.out.println("Remaning friends:"+list);

	}

}

package com.sapient.ace.mylist;

import java.util.Comparator;
import java.util.PriorityQueue;

public class TestQueue {
	
	public static void main(String args[]){
		
		PriorityQueue<Employee> empQ = new PriorityQueue<>();
		empQ.add(new Employee(444, "ajay"));
		empQ.add(new Employee(1444, "rajay"));
		empQ.add(new Employee(53444, "atttjay"));
		empQ.add(new Employee(5444, "astjay"));
		empQ.add(new Employee(4244, "a223jay"));
		
		
		System.out.println("before:"+ empQ);
		final Comparator<Employee> myComp = new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpID().compareTo(o2.getEmpID());
			}
		};
		
		
		
		
	}

}

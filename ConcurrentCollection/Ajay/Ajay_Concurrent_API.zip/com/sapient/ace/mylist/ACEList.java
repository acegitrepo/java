package com.sapient.ace.mylist;

import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ACEList<T> extends ArrayList<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4454814434613676438L;
	
	private ReadWriteLock lock = new ReentrantReadWriteLock(true);

	@Override
	public boolean add(T t) {
		// getWrite lock
		// 
		
		final Lock writeLock = lock.writeLock();
		
		try {
			writeLock.lock();
			if (canElementAdded()) {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return super.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			writeLock.unlock();
		}
		return false;
	}

	private boolean canElementAdded() {
		return false;
	}

	@Override
	public T get(int index) {
		if (canElementFetched()) {
			return super.get(index);
		}
		return null;
	}

	private boolean canElementFetched() {
		return false;
	}

}

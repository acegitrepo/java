package com.sapient.ace.mylist;

import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class TestHashMap {
	
	public static void main(String args[]){
		Random rand = new Random();
		Set<Integer> set = new HashSet<>();
		for (int i = 0; i < 15; i++) {
			set.add(rand.nextInt(10));
		}
		System.out.println("show set:"+set);
		System.out.println("NOw sort in descending order");
		
		Set<Integer> desOrder = new TreeSet<>(Collections.reverseOrder());
		desOrder.addAll(set);
		set = desOrder;
		
		System.out.println("set in descending order:"+set);
		for (int i = 0; i < 15; i++) {
			set.add(rand.nextInt(10));
		}
		
		System.out.println("show set:"+set);
		
	}
}
package com.example.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class CollectionExample {

	public static void main(String[] args) {
		List<Fruit> fruits=new ArrayList<Fruit>();
		for(int i=0;i<args.length;i++){
			fruits.add(new Fruit(args[i]));
		}
		
		Collections.sort(fruits);
		
		System.out.println(fruits.toString());
		
		int item=Collections.binarySearch(fruits, new Fruit("Orange"));
		
		System.out.println(item);
		
		List<Fruit> list=new LinkedList<>(fruits);
		list.remove(2);
		
		System.out.println(list.toString());
		
		Random random=new Random();
		Set<Integer> numSet=new TreeSet<>(new Descending());
		for(int i=0;i<15;i++){
			numSet.add(random.nextInt(10));
		}
		System.out.println(numSet.toString());
		for(int i=0;i<15;i++){
			numSet.add(random.nextInt(10));
		}
		System.out.println(numSet.toString());
		
		Set fruitSet=new TreeSet<>(fruits);
		System.out.println(fruitSet.toString());
		
		Employee emp1=new Employee(1,"Sanjay");
		Employee emp2=new Employee(2,"Mohit");
		
//		Set empSet=new TreeSet<>(new StringCompare());
		Set empSet=new TreeSet<>();
		empSet.add(emp1);
		empSet.add(emp2);
		
		System.out.println(empSet.toString());
		
		PriorityQueue<Employee> pqEmployee=new PriorityQueue<>(new Increasing());
		pqEmployee.addAll(empSet);
		
		System.out.println(pqEmployee.toString());
		
		pqEmployee.add(new Employee(1,"Rohit"));
		
		System.out.println(pqEmployee.toString());
		
	}

}

class Increasing implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getEmployeeId()-o2.getEmployeeId();
	}
	
}

class StringCompare implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getName().compareTo(o2.getName());
	}
	
}

class Employee implements Comparable<Employee>{

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + "]";
	}




	private int employeeId;
	private String name;
	
	public Employee(){
		
	}
	
	public Employee(int id, String name){
		Random random=new Random();
		
		this.employeeId=random.nextInt(999);
		this.name=name;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}




	public String getName() {
		return name;
	}




	@Override
	public int compareTo(Employee o) {
		return this.getEmployeeId()-o.getEmployeeId();
	}
	
}


class Descending implements Comparator<Integer>{

	@Override
	public int compare(Integer o1, Integer o2) {
		return o2.compareTo(o1);
	}
	
}
class Fruit implements Comparable<Fruit>{
	private String name;
	
	public Fruit(){
		
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fruit other = (Fruit) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public Fruit(String name){
		this.name=name;
	}
	
	public String getName(){
		return this.name;
	}

	@Override
	public int compareTo(Fruit o) {
		return this.getName().compareToIgnoreCase(o.getName());
	}

	@Override
	public String toString() {
		return "Fruit [name=" + name + "]";
	}

	
}

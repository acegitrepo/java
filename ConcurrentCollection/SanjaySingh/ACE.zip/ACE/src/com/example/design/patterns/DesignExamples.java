package com.example.design.patterns;

import java.util.Scanner;

public class DesignExamples {

	public static void main(String[] args) {
		//Command Pattern
		Scanner scan =new Scanner(System.in);
		
		System.out.println("1. File operations on Unix\n2. File operations in Windows");
		int userFileInput=scan.nextInt();
		
		System.out.println("1. Open a file\n2. Read a file\n3. Write a file");
		int userOperationInput=scan.nextInt();
		Invoker invoke=new Invoker();
		
		switch(userOperationInput){
		case 1:
			invoke.executeCommand(new Open());
			break;
		case 2:
			invoke.executeCommand(new Read());
			break;
		case 3:
			invoke.executeCommand(new Write());
			break;
			default:
				System.out.println("Invalid Input!");
				break;
		}
		scan.close();
		
	}

}

interface Command{
	void execute();
}

class Open implements Command{

	@Override
	public void execute() {
		System.out.println("Opening the file");
	}
	
}

class Write implements Command{

	@Override
	public void execute() {
		System.out.println("Writing the file");
	}
	
}

class Read implements Command{

	@Override
	public void execute() {
		System.out.println("Reading the file");
	}
	
}

class Invoker{
	public void executeCommand(Command command){
		command.execute();
	}
	
}

interface Visitor{
	void visit(Unix unix);
	void visit(Windows windows);
}

interface Visitable{
	void accept(Visitor visitor);
}

class Unix implements Visitable{

	@Override
	public void accept(Visitor visitor) {
		visitor.visit(this);
	}
	
}

class Windows implements Visitable{

	@Override
	public void accept(Visitor visitor) {
		visitor.visit(this);
	}
	
}

package com.example.concurrent;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class UsingArrayBlockingQueue {

	public static void main(String[] args) {
		BlockingQueue<Integer> block=new ArrayBlockingQueue<>(10);
		
		Thread prod=new Producer(block);
		Thread cons=new Consumer(block);
		
		prod.start();
		cons.start();
		
	}

}

package com.example.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class UsingSynchronousQueue {
	
	public static void main(String[] args) {
		BlockingQueue<Integer> block=new SynchronousQueue<Integer>();
		
		Thread prod=new Producer(block);
		Thread cons=new Consumer(block);
		
		prod.start();
		cons.start();
		
	}
}

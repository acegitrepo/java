package com.example.concurrent;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierExample {

	public static void main(String[] args) {
		CyclicBarrier barrier=new CyclicBarrier(3);
		
		Thread xmlSource=new Thread(new XmlBarrier(barrier));
		Thread dbsSource=new Thread(new DBSBarrier(barrier));
		Thread csvSource=new Thread(new CsvBarrier(barrier));
		
		xmlSource.start();
		dbsSource.start();
		csvSource.start();
		
		
		
		System.out.println("Exit");
	}

}

class XmlBarrier implements Runnable{

	private final CyclicBarrier barrier;
	
	public XmlBarrier(CyclicBarrier barrier) {
		super();
		this.barrier = barrier;
	}

	@Override
	public void run() {
		try {
			barrier.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Xml Processing finished");
	}
	
}


class DBSBarrier implements Runnable{

	private final CyclicBarrier barrier;
	
	public DBSBarrier(CyclicBarrier barrier) {
		super();
		this.barrier = barrier;
	}

	@Override
	public void run() {
		try {
			barrier.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("DBS Processing finished");
	}
	
}

class CsvBarrier implements Runnable{
	private final CyclicBarrier barrier;
	
	public CsvBarrier(CyclicBarrier barrier) {
		super();
		this.barrier = barrier;
	}

	@Override
	public void run() {
		try {
			barrier.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Csv Processing finished");
	}
}

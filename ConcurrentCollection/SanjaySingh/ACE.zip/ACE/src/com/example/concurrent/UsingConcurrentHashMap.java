package com.example.concurrent;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class UsingConcurrentHashMap {

	public static void main(String[] args) {
		ConcurrentMap map=new ConcurrentHashMap(1);
		
		Thread prod=new Prod(map);
		Thread cons=new Cons(map);
		
		prod.start();
		cons.start();
	}

}

class Prod extends Thread{
	
	ConcurrentMap map;
	
	public Prod(ConcurrentMap map){
		this.map=map;
	}
	
	@Override
	public void run(){
		System.out.println("Produced: "+map.putIfAbsent("Produced", new Integer(1)));
		System.out.println("Produced: "+map.putIfAbsent("Produced", new Integer(2)));
	}
}

class Cons extends Thread{
	
	ConcurrentMap map;
	
	public Cons(ConcurrentMap map){
		this.map=map;
	}
	
	@Override
	public void run(){
		Iterator<String> itr=map.keySet().iterator();
		while(itr.hasNext()){
			String temp=itr.next();
			System.out.println("Consumed: "+map.get(temp));
		}
		
	}
}
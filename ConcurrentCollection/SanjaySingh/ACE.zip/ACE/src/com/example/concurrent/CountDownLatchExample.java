package com.example.concurrent;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {

	public static void main(String[] args) {
		CountDownLatch latch=new CountDownLatch(3);
		Thread xmlSource=new Thread(new Xml(latch));
		Thread dbsSource=new Thread(new DBS(latch));
		Thread csvSource=new Thread(new Csv(latch));
		
		xmlSource.start();
		dbsSource.start();
		csvSource.start();
		
		try {
			latch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Exit");
	}

}

class Xml implements Runnable{

	private final CountDownLatch latch;
	
	public Xml(CountDownLatch latch) {
		super();
		this.latch = latch;
	}

	@Override
	public void run() {
		System.out.println("Xml Processing finished");
		latch.countDown();
	}
	
}


class DBS implements Runnable{

	private final CountDownLatch latch;
	
	public DBS(CountDownLatch latch) {
		super();
		this.latch = latch;
	}



	@Override
	public void run() {
		System.out.println("DBS Processing finished");
		latch.countDown();
	}
	
}

class Csv implements Runnable{
private final CountDownLatch latch;
	
	public Csv(CountDownLatch latch) {
		super();
		this.latch = latch;
	}



	@Override
	public void run() {
		System.out.println("Csv Processing finished");
		latch.countDown();
	}
}
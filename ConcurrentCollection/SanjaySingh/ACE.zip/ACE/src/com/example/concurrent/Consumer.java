package com.example.concurrent;

import java.util.concurrent.BlockingQueue;

public class Consumer extends Thread{
	BlockingQueue<Integer> block;
	
	public Consumer(BlockingQueue<Integer> block){
		this.block=block;
	}
	
	@Override
	public void run(){
		for(int i=0;i<10;i++){
			try {
				System.out.println("Consumed: "+block.take());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

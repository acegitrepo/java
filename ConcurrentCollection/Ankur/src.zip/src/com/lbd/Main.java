package com.lbd;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;


public class Main {
	
	
	
	public static void main (String [] args)
	{
	BlockingQueue<Integer> queue = new LinkedBlockingDeque<>(7);
	
	Producer producer = new Producer(queue);
	Consumer consume = new Consumer(queue);
	
	Thread producerThread = new Thread(producer);
	Thread consumerThread = new Thread(consume);
	producerThread.start();
	consumerThread.start();
   		 
	}

}

package com.sapient.ace;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierImp {

	public CyclicBarrierImp() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		CyclicBarrier cyclicBarrier = new CyclicBarrier(2);
		Thread thread1= new Thread(new Racer1(cyclicBarrier));
		Thread thread2= new Thread(new Racer2(cyclicBarrier));
		
		System.out.println("Going to race");
		
		thread1.start();
		thread2.start();
		

	}

}


class Racer1 implements Runnable
{
	private CyclicBarrier cyclicBarrier;
	public Racer1(CyclicBarrier countDownLatch)
	{
		this.cyclicBarrier=countDownLatch;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Racer1 preparing for race");
		
		try {
			cyclicBarrier.await();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (BrokenBarrierException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Racer1 racing");
		
		
	}

}


class Racer2 implements Runnable
{
	private CyclicBarrier cyclicBarrier;
	public Racer2(CyclicBarrier countDownLatch)
	{
		this.cyclicBarrier=countDownLatch;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Racer2 preparing for race");
		
		try {
			cyclicBarrier.await();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (BrokenBarrierException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Racer2 racing");
		
		
	}

}

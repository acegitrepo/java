package com.sapient.ace;

import java.util.concurrent.CountDownLatch;

public class LatchImp {

	public LatchImp() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		CountDownLatch countDownLatch = new CountDownLatch(2);
		Thread thread1= new Thread(new Source1(countDownLatch));
		Thread thread2= new Thread(new Source2(countDownLatch));
		
		System.out.println("Going to start process");
		
		thread1.start();
		thread2.start();
		
		
		countDownLatch.await();
		
		System.out.println("Processing has finished");

	}

	
	
	
}

class Source1 implements Runnable
{
	private CountDownLatch countDownLatch;
	public Source1(CountDownLatch countDownLatch)
	{
		this.countDownLatch=countDownLatch;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Source1 Processing start");
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Source1 Processing end");
		countDownLatch.countDown();
		
	}

}


class Source2 implements Runnable
{
	private CountDownLatch countDownLatch;
	public Source2(CountDownLatch countDownLatch)
	{
		this.countDownLatch=countDownLatch;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Source2 Processing start");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Source2 Processing end");
		countDownLatch.countDown();
		
	}

}
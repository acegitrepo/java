package com.practise.concurrent.queues.synchrounousqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class ConsumerBlockingQueue implements Runnable{

	
	private BlockingQueue< Integer> queue;
	
	
	public ConsumerBlockingQueue(BlockingQueue<Integer> queue) {
	this.queue=queue;
	}
	
	@Override
	public void run() {
		while(true){
		try {
			TimeUnit.MILLISECONDS.sleep(500);
			int var = queue.take();
			System.out.println("Consumed=="+ var);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}

package com.practise.concurrent.queues.synchrounousqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class MainClass {

	private  static BlockingQueue<Integer> queue=null;

	
	public MainClass() {
		
	}
	
	public static void main(String[] args) {
		
		queue = new SynchronousQueue<Integer>();
		System.out.println("Starting consumer producer threads...");
		ConsumerBlockingQueue consumer = new ConsumerBlockingQueue(queue);
		ProducerBlockingQueue producer = new ProducerBlockingQueue(queue);
	
		
		Thread producerThread = new Thread(producer);
		Thread consumerThread = new Thread(consumer);
		
		producerThread.start();
		consumerThread.start();
		
	}
	
	
}

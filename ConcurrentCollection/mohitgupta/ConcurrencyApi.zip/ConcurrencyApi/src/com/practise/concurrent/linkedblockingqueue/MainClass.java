package com.practise.concurrent.linkedblockingqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MainClass {

	private  static BlockingQueue<Integer> storage=null;

	
	public MainClass() {
		
	}
	
	public static void main(String[] args) {
		
		storage = new LinkedBlockingQueue<Integer>(100);
		System.out.println("Starting consumer producer threads...");
		ConsumerBlockingQueue consumer = new ConsumerBlockingQueue(storage);
		ProducerBlockingQueue producer = new ProducerBlockingQueue(storage);
	
		
		Thread producerThread = new Thread(producer);
		Thread consumerThread = new Thread(consumer);
		
		producerThread.start();
		consumerThread.start();
		
	}
	
	
}

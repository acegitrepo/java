package com.practise.concurrent.queues.delayqueue;

import java.util.concurrent.TimeUnit;

public interface Delayed extends Comparable {

    long getDelay(TimeUnit unit);
}
package com.practise.concurrent.queues.delayqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;

public class MainClass {

	

	
	public MainClass() {
		
	}
	
		
		public static void main(String[] args) {
			final BlockingQueue<DelayElement> queue = new DelayQueue<DelayElement>();

			ProducerDelayBlockingQueue queueProducer = new ProducerDelayBlockingQueue(queue);
			new Thread(queueProducer).start();

			ConsumerDelayBlockingQueue queueConsumer1 = new ConsumerDelayBlockingQueue(queue);
			new Thread(queueConsumer1).start();

			ConsumerDelayBlockingQueue queueConsumer2 = new ConsumerDelayBlockingQueue(queue);
			new Thread(queueConsumer2).start();

		}
	
	
}

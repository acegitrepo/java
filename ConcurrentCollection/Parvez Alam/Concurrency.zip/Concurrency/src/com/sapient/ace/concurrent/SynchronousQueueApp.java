package com.sapient.ace.concurrent;

import java.util.concurrent.SynchronousQueue;

public class SynchronousQueueApp {

	public static void main(String[] args) {

		SynchronousQueue<String> queue = new SynchronousQueue<>();

		Thread producer = new Thread(() -> {

			String msg = "Hello World!";
			try {
				queue.put(msg);// It will block here

				System.out.println(Thread.currentThread().getName()+" pulished message : "+msg);

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}, "Producer");

		producer.start();

		Thread consumer  = new Thread(() -> {

			try {
				String msg = queue.take();

				System.out.println(Thread.currentThread().getName()+" consumed message : "+msg);

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}, "Consumer");
		
		consumer.start();
	}
}

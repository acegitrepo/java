package com.sapient.ace.concurrent;

import java.util.Random;
import java.util.concurrent.BlockingQueue;

class Producer implements Runnable{

	private BlockingQueue<Integer> queue;
	
	public Producer(){}
	
	public Producer(BlockingQueue<Integer> queue){
		this.queue = queue;
	}
	
	@Override
	public void run() {
		
		while(true){
			
			Random random  =new Random();
			int number = random.nextInt(100);
			
			try {
				System.out.println(Thread.currentThread().getName()+" produced : "+number+"; Queue size "+queue.size());
				
				queue.put(number);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	
}


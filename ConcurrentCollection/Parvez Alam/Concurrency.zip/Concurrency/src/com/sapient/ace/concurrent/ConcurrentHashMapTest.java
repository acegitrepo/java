package com.sapient.ace.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ConcurrentHashMapTest {

	public ConcurrentHashMapTest() {
	}	

	public static void main(String[] args) {
		List<String> keyList = new ArrayList<>();

		keyList.add("K1");
		keyList.add("K2");
		keyList.add("K1");
		keyList.add("K2");
		keyList.add("K3");
		keyList.add("K1");

		ConcurrentHashMap<String, AtomicInteger> map = new ConcurrentHashMap<>();

		for(String key : keyList){
			AtomicInteger value = map.putIfAbsent(key, new AtomicInteger(1));
			if(value !=null)
				value.getAndIncrement();
		}

		System.out.println("Key-Value in Map : "+map);

	}

}

package com.sapient.ace.concurrent.delayedqueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;

public class DelayedQueueTest {

	public static void main(String[] args) {
		final BlockingQueue<DelayElement> queue = new DelayQueue<DelayElement>();

		ProducerDelayBlockingQueue queueProducer = new ProducerDelayBlockingQueue(queue);
		new Thread(queueProducer, "Producer").start();

		ConsumerDelayBlockingQueue queueConsumer1 = new ConsumerDelayBlockingQueue(queue);
		new Thread(queueConsumer1, "Consumer 1 ").start();

		ConsumerDelayBlockingQueue queueConsumer2 = new ConsumerDelayBlockingQueue(queue);
		new Thread(queueConsumer2, "Consumer 2").start();

		//Will stop the execution of program
		Thread stopThread = new Thread(()->{
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.exit(0);
		});

	//	stopThread.start();


	}


}

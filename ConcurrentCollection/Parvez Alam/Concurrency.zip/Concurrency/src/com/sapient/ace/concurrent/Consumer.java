package com.sapient.ace.concurrent;

import java.util.concurrent.BlockingQueue;

class Consumer implements Runnable{
	
private BlockingQueue<Integer> queue;
	
	public Consumer(){}
	
	public Consumer(BlockingQueue<Integer> queue){
		this.queue = queue;
	}
	
	@Override
	public void run() {

		while(true){
			try {
				Thread.sleep(300);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				int number = queue.take();
				
				System.out.println(Thread.currentThread().getName()+ " consumed :  "+number+"; Queue size "+queue.size());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

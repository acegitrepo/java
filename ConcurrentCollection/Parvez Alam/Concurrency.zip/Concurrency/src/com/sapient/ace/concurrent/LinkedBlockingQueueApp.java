package com.sapient.ace.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class LinkedBlockingQueueApp {

	public static void main(String[] args) {
		BlockingQueue<Integer> queue = new LinkedBlockingQueue<>();


		Thread producer = new Thread(new Producer(queue),"Producer");
		Thread consumer = new Thread(new Consumer(queue),"Consumer");

		producer.start();
		consumer.start();

		//Will stop the execution of program
		Thread stopThread = new Thread(()->{
			try {
					Thread.sleep(2000);
			} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.exit(0);
		});
		stopThread.start();
	}

}

package com.sapient.ace.countdownlatch;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

public class XMLDataLoader implements Callable<String>{

	private CountDownLatch cdl;
	
	public XMLDataLoader() {
		// TODO Auto-generated constructor stub
	}
	
	public XMLDataLoader(CountDownLatch cdl){
		this.cdl = cdl;
	}
	
	@Override
	public String call() throws Exception {

		String msg = "Data Lodaed From XML";
		
		cdl.countDown();
		return msg;
	}

}

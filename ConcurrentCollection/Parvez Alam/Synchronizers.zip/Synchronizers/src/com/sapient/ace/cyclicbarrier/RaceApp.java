package com.sapient.ace.cyclicbarrier;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RaceApp {

	public RaceApp() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		
		Runnable barrierAction = new Runnable() {
			
			@Override
			public void run() {
			System.out.println("\nAll Players reached at barrier/commonm point. Let's play...\n");	
			}
		};
		
		CyclicBarrier cBarrier = new CyclicBarrier(3, barrierAction);
		
		ExecutorService ex = Executors.newFixedThreadPool(3);
		
		List<Runnable> tasks = new ArrayList<>();
		
		tasks.add(new Player(cBarrier));
		tasks.add(new Player(cBarrier));
		tasks.add(new Player(cBarrier));
		
		for(Runnable task : tasks){
			ex.submit(task);
		}
		
		ex.shutdown();
		
	}
}

package com.sapient.ace.countdownlatch;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

public class DBDataLoader implements Callable<String>{

	private CountDownLatch cdl;
	public DBDataLoader() {
	}
	
	public DBDataLoader(CountDownLatch cdl){
		this.cdl = cdl;
	}
	
	@Override
	public String call() throws Exception {
		String msg = "Data Loaded from DB";
		cdl.countDown();
		
		return msg;
	}

}

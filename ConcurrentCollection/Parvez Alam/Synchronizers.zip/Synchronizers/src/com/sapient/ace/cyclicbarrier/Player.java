package com.sapient.ace.cyclicbarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Player implements Runnable {

	private CyclicBarrier cBarrier;
	
	public Player() {
	}
	
	public Player(CyclicBarrier cBarrier){
		this.cBarrier = cBarrier;
	}
	
	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName()+" waiting at barrier...");
		
		try {
			cBarrier.await();
		} catch (InterruptedException | BrokenBarrierException e) {
			e.printStackTrace();
		}
		
		System.out.println(Thread.currentThread().getName()+" playing...");
		
	}

}

package com.sapient.ace.countdownlatch;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class DataProcresssingApp {

	public DataProcresssingApp() {
	}

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		CountDownLatch cdl = new CountDownLatch(2);
		
		ExecutorService ex = Executors.newFixedThreadPool(2);
		
		List<Callable<String>> tasks = new ArrayList<>();
		
		tasks.add(new DBDataLoader(cdl));
		tasks.add(new XMLDataLoader(cdl));
		
		List<Future<String>>  futureResult = ex.invokeAll(tasks);
		
		cdl.await();
		
		//Processing Data 
		for(Future<String> data : futureResult){
			System.out.println(data.get());
		}
		
		ex.shutdown();
	}
}
